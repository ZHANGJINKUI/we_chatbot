import http from '@/utils/http'
import type { ChatListRequest, ChatItem } from '@/types/ChatType'

/** 请求对话列表
 * @param userid
 * @param username
 * **/
export const fetchChatListApi = (params: ChatListRequest): Promise<ChatItem[]> => {
  return http.post('/chat/list', params)
}

/** 删除文件
 * @param id
 * **/
export const deleteChatApi = (id: string) => {
  return http.delete(`/chat/delete/${id}`);
}

