<template>
  <div class="chat-history">
    <div class="history-header">
      <h3>历史对话</h3>
    </div>
    <div class="history-list">
      <a-list :data-source="chatStore.chatListData" :loading="chatStore.loading">
        <template #empty>
          <div class="empty-history">
            <p>暂无历史对话</p>
          </div>
        </template>
        <template #item="{ item }">
          <a-list-item
            :class="['history-item', { active: item.id === chatStore.currentChatId }]"
            @click="selectChat(item.id)"
          >
            <div class="item-content">
              <div class="item-title">{{ item.title || '新对话' }}</div>
              <div class="item-time">{{ formatTime(item.createAt) }}</div>
            </div>
            <template #actions>
              <a-button type="text" danger @click.stop="deleteChat(item.id)">
                <template #icon><DeleteOutlined /></template>
              </a-button>
            </template>
          </a-list-item>
        </template>
      </a-list>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useChatStore } from '@/stores/chat'
import { DeleteOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import { onMounted } from 'vue'

const chatStore = useChatStore()

// 格式化时间
const formatTime = (timestamp: number) => {
  const date = new Date(timestamp)
  return date.toLocaleString()
}

// 选择对话
const selectChat = (chatId: string) => {
  chatStore.setCurrentChatId(chatId)
}

// 删除对话
const deleteChat = async (chatId: string) => {
  try {
    await chatStore.deleteChat(chatId)
    message.success('删除成功')
  } catch (error) {
    message.error('删除失败')
  }
}

// 初始化时获取对话列表
onMounted(() => {
  chatStore.fetchChatList()
})
</script>

<style scoped>
.chat-history {
  height: 100%;
  display: flex;
  flex-direction: column;
  background-color: #fff;
}

.history-header {
  padding: 16px;
  border-bottom: 1px solid #f0f0f0;
}

.history-list {
  flex: 1;
  overflow-y: auto;
}

.history-item {
  padding: 12px 16px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.history-item:hover {
  background-color: #f5f5f5;
}

.history-item.active {
  background-color: #e6f7ff;
}

.item-content {
  flex: 1;
}

.item-title {
  font-weight: 500;
  margin-bottom: 4px;
}

.item-time {
  font-size: 12px;
  color: #999;
}
</style> 