<template>
  <!-- <div class="测试区域" style="background-color: antiquewhite">
    <div v-if="loading">Loading...</div>
    <div v-else>{{ chatContent }}</div>
  </div> -->
  <div class="chat-container">
    <div class="chat-header">
      <div class="header-left">
        <h2>{{ currentChat?.title || '新对话' }}</h2>
      </div>
      <div class="header-center" v-if="currentFileId">
        <span class="document-status">
          <span>当前文档: {{ fileStore.currentFile.filename }}</span>
          <a-tag v-if="fileStore.hasModifiedDoc" color="green">已修改</a-tag>
          <a-tag v-else color="blue">未修改</a-tag>
        </span>
      </div>
      <div class="header-right">
        <a-button type="primary" @click="createNewChat">新对话</a-button>
        <div v-if="showDownloadButton" class="action-buttons">
          <a-button type="primary" @click="downloadDocument">下载文档</a-button>
          <a-button v-if="fileStore.processedContent" @click="previewDocument">预览文档</a-button>
        </div>
      </div>
    </div>
    <Chat
      ref="chatRef"
      :roleConfig="roleInfo"
      :chats="chats"
      style="margin: 0 auto"
      :uploadProps="{ disabled: true, action: '' }"
      :upload-tip-props="{ content: '已禁用' }"
      :onMessageSend="sendMessage"
      :components="{}"
    >
    </Chat>
    
    <a-modal
      v-model:visible="previewModalVisible"
      title="文档预览"
      width="800px"
      :footer="null"
    >
      <div class="document-preview">
        <pre>{{ fileStore.processedContent }}</pre>
      </div>
    </a-modal>
  </div>
</template>
<script setup lang="ts">
import { ref, watch, useTemplateRef, computed, nextTick, onMounted } from 'vue'
import { message, Button as AButton, Tag as ATag, Modal as AModal } from 'ant-design-vue'
import { useChatStore } from '@/stores/chat'
import { useAuthStore } from '@/stores/auth'
import { useFileStore } from '@/stores/file'
// -- 对话UI组件 -------------------------------
import { Chat } from '@kousum/semi-ui-vue'
import type { Message } from '@/types/ChatType'
// @ts-ignore - Ignore missing type declaration for openRouter
import openRouterService from '@/api/openRouter'
// 引入weChatbot服务
import { sendChatRequest, downloadProcessedDocument, healthCheck } from '@/services/weChatbotService'
// --    图标    ------------------------------
import systemLogo from '@/assets/system.png'
import assistantLogo from '@/assets/robot.png'
import userLogo from '@/assets/user-avatar.png'
// --------------------------------------------

defineOptions({
  name: 'ChatPage'
})
// --------------------------------------------
const chatStore = useChatStore()
const fileStore = useFileStore()
const currentChat = computed(() => chatStore.currentChat)
const currentChatId = computed(() => currentChat.value.id)
const showDownloadButton = computed(() => fileStore.hasModifiedDoc && currentChatId.value)

// 检查后端连接状态
const checkBackendConnection = async () => {
  const isHealthy = await healthCheck();
  if (!isHealthy) {
    message.warning('无法连接到后端服务，某些功能可能无法正常工作');
  }
};

// 监听当前chatID变化
watch(
  () => currentChatId.value,
  async newChatId => {
    if (newChatId) {
      try {
        // 根据chatID获取内容
        console.log('当前对话ID:', newChatId);
      } catch (error) {
        console.error('Failed to load chat:', error)
      }
    } else {
      console.log('No chat selected');
    }
  },
  { immediate: true }
)
// --------------------------------------------
const authStore = useAuthStore()
const currentUser = computed(() => authStore.currentUser)
const username = computed(() => currentUser.value?.username)

// 定义角色信息
const roleInfo = {
  user: {
    name: username.value || '用户', // 使用当前登录用户名
    avatar: userLogo
  },
  assistant: {
    name: '小助手',
    avatar: assistantLogo
  },
  system: {
    name: '系统消息',
    avatar: systemLogo
  }
}
// --------------------------------------------
const chatRef = useTemplateRef('chatRef')
let chats = ref<Message[]>([])

// 初始化聊天消息
const initializeChat = () => {
  chats.value = [
    {
      role: 'system',
      id: '0',
      createAt: new Date().getTime(),
      content: "Hello, I'm your AI assistant.",
      status: 'complete'
    }
  ]
}

// 创建新对话
const createNewChat = async () => {
  try {
    // 创建一个新的chat
    await chatStore.createNewChat()
    // 重置消息列表
    initializeChat()
    // 重置文档修改状态
    fileStore.setHasModifiedDoc(false)
    message.success('创建新对话成功');
  } catch (error) {
    console.error('Failed to create new chat:', error)
    message.error('创建新对话失败')
  }
}

// 下载处理后的文档
const downloadDocument = async () => {
  try {
    if (!currentChatId.value) {
      message.warning('没有当前对话ID')
      return
    }
    
    message.loading('下载中...')
    const blob = await downloadProcessedDocument(currentChatId.value)
    
    // 生成下载链接
    const url = window.URL.createObjectURL(blob)
    const filename = fileStore.currentFile.filename || 'processed_document.txt'
    
    // 分割文件名和扩展名
    const lastDotIndex = filename.lastIndexOf('.')
    const name = lastDotIndex !== -1 ? filename.substring(0, lastDotIndex) : filename
    const extension = lastDotIndex !== -1 ? filename.substring(lastDotIndex) : ''
    
    // 添加"processed"标记和时间戳
    const timestamp = new Date().getTime()
    const newFilename = `${name}_processed_${timestamp}${extension}`
    
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', newFilename)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    
    message.success('下载成功')
  } catch (error) {
    console.error('下载处理后的文档失败:', error)
    message.error('下载失败')
  }
}

// 预览处理后的文档
const previewDocument = () => {
  if (!fileStore.processedContent) {
    message.warning('没有处理后的文档内容')
    return
  }
  previewModalVisible.value = true
}

// 在组件挂载后初始化聊天
onMounted(() => {
  initializeChat()
  checkBackendConnection();
  
  // 监听存储中的处理文档更新事件
  window.addEventListener('processed-document-updated', (event: any) => {
    if (event.detail && event.detail.content) {
      message.success('文档处理完成，可以下载或预览')
    }
  })
})

// --------------------------------------------
// 检查消息是否与文档处理相关
const isDocumentRelatedQuery = (messageText: string): boolean => {
  const docKeywords = [
    '文档', '公文', '纠错', '润色', '文件', 
    '上传', '处理', '修改', '校对', '检查',
    '改进', '修复', '纠正', '审核', '改良'
  ]
  return docKeywords.some(keyword => messageText.includes(keyword))
}

// 发送消息
const sendMessage = async (msg: string) => {
  if (!msg.trim()) return;
  
  console.log('发送消息:', msg)
  
  // 添加用户消息
  const userMessageId = currentChatId.value + new Date().getTime() + '0';
  chats.value.push({
    role: 'user',
    id: userMessageId,
    createAt: new Date().getTime(),
    content: msg,
    status: 'complete'
  })
  
  // 添加助手消息（初始状态为加载中）
  const assistantMessageId = currentChatId.value + new Date().getTime() + '1';
  chats.value.push({
    role: 'assistant',
    id: assistantMessageId,
    createAt: new Date().getTime(),
    content: '...', // 默认内容，防止空字符串渲染问题
    status: 'loading'
  })
  
  // 滚动到底部
  scrollToBottom()
  
  try {
    // 确定当前助手消息的索引
    const assistantIndex = chats.value.length - 1
    
    // 检查是否是文档相关的查询
    const isDocRequest = isDocumentRelatedQuery(msg)
    const hasUploadedDoc = fileStore.currentFile && fileStore.currentFile.id
    
    if (isDocRequest && hasUploadedDoc) {
      console.log('检测到文档相关查询，将使用当前文档：', fileStore.currentFile.filename)
    }
    
    // 优先使用weChatbotService调用deepseek和MCP服务
    // 无论是否有文档都优先使用后端服务
    console.log('使用weChatbotService发送请求以调用deepseek和MCP...')
    
    await sendChatRequest(
      msg,
      chats.value.slice(0, -1), // 不包括最后一条助手消息
      (content) => {
        // 处理流式内容更新
        if (chats.value[assistantIndex].content === '...' && content) {
          chats.value[assistantIndex].content = content
        } else {
          chats.value[assistantIndex].content = content
        }
        scrollToBottom()
      },
      () => {
        // 处理完成回调
        chats.value[assistantIndex].status = 'complete'
        scrollToBottom()
        
        // 检查是否有文档内容更新
        if (fileStore.hasModifiedDoc && fileStore.processedContent) {
          console.log('检测到文档已更新，长度:', fileStore.processedContent.length)
          message.success('文档已更新，您可以在文件页面查看或下载')
          
          // 文档处理后跳转提示
          if (isDocRequest && hasUploadedDoc) {
            nextTick(() => {
              message.info('文档处理完成，您可以点击下载按钮获取处理后的文档或在文件页面查看对比效果')
            })
          }
        }
      },
      async (error) => {
        // 处理错误回调
        console.error('weChatbotService错误，尝试使用备用服务:', error)
        
        // 如果weChatbotService失败，回退到使用openRouterService
        try {
          // 使用openRouterService处理一般请求
          const response = await openRouterService.sendMessage(chats.value)
          
          // 检查是否有消息
          if (chats.value.length === 0) return
          
          // 更新最后一条消息的状态
          if (chats.value.length > 0) {
            // 确保内容不为空，防止渲染问题
            const currentContent = chats.value[assistantIndex].content || '...'
            chats.value[assistantIndex] = {
              ...chats.value[assistantIndex],
              content: currentContent,
              status: 'incomplete'
            }
          }
          
          // 处理流式响应
          for await (const chunk of response) {
            const content = chunk.choices[0]?.delta?.content || ''
            // 如果是第一个块并且我们仍有占位符，则替换它
            if (chats.value[assistantIndex].content === '...' && content) {
              chats.value[assistantIndex].content = content
            } else {
              chats.value[assistantIndex].content += content
            }
            // 每次添加内容后滚动到底部
            scrollToBottom()
          }
          
          // 完成处理
          chats.value[assistantIndex].status = 'complete'
        } catch (fallbackError) {
          console.error('备用服务也失败:', fallbackError)
          chats.value[assistantIndex].content = '发送消息时出错，请重试。'
          chats.value[assistantIndex].status = 'error'
        }
        
        scrollToBottom()
      }
    )
    
    // 确保最终内容不为空
    if (
      !chats.value[assistantIndex].content ||
      chats.value[assistantIndex].content === '...'
    ) {
      chats.value[assistantIndex].content = '未收到回复。'
    }
    
    // 最后再次滚动到底部
    scrollToBottom()
    
    // 保存聊天记录到store
    if (currentChatId.value) {
      await chatStore.updateCurrentChat({
        ...currentChat.value,
        messages: chats.value
      })
    }
  } catch (error) {
    console.error('发送消息错误:', error)
    
    // 处理错误
    const assistantIndex = chats.value.length - 1
    if (assistantIndex >= 0) {
      chats.value[assistantIndex].content = '发送消息时出错，请重试。'
      chats.value[assistantIndex].status = 'error'
    }
    
    message.error('发送消息失败，请重试')
    scrollToBottom()
  }
}
// --------------------------------------------
// 滚动到底部的函数
const scrollToBottom = () => {
  nextTick(() => {
    // 尝试多种方式找到聊天容器并滚动到底部
    // 1. 使用 semi-chat 类名查找
    const chatElement = document.querySelector('.semi-chat') as HTMLElement
    if (chatElement) {
      chatElement.scrollTop = chatElement.scrollHeight
    }

    // 2. 尝试使用组件的内置方法
    try {
      // @ts-ignore - The scrollToBottom method exists at runtime but not in type definitions
      if (chatRef.value && typeof chatRef.value.scrollToBottom === 'function') {
        // @ts-ignore
        chatRef.value.scrollToBottom(true)
      }
    } catch (error) {
      console.error('Error scrolling to bottom:', error)
    }

    // 3. 尝试查找消息容器的其他可能类名
    const messageContainer = document.querySelector('.semi-chat-messages') as HTMLElement
    if (messageContainer) {
      messageContainer.scrollTop = messageContainer.scrollHeight
    }
  })
}

// --------------------------------------------
const previewModalVisible = ref(false)
const currentFileId = computed(() => fileStore.currentFile?.id || '')
</script>
<style lang="less" scoped>
.chat-container {
  padding: 5px;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.chat-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
  padding: 8px 16px;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.header-left {
  flex: 1;
  h2 {
    margin: 0;
    font-size: 18px;
    color: #333;
  }
}

.header-center {
  flex: 2;
  text-align: center;
}

.header-right {
  flex: 1;
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.document-status {
  display: flex;
  align-items: center;
  gap: 8px;
}

.action-buttons {
  display: flex;
  gap: 10px;
}

.document-preview {
  max-height: 500px;
  overflow-y: auto;
  border: 1px solid #e8e8e8;
  padding: 10px;
  background-color: #f9f9f9;
  
  pre {
    white-space: pre-wrap;
    word-wrap: break-word;
    margin: 0;
    font-family: 'Courier New', Courier, monospace;
  }
}
</style>
