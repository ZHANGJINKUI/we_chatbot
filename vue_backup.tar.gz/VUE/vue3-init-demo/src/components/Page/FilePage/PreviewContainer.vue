<template>
  <div class="docx-preview">
    <!-- loading -->
    <div v-if="loading" style="display: flex; justify-content: center; align-items: center">
      <a-spin style="font-size: 28px; margin-right: 10px" />
      <span>正在加载...</span>
    </div>
    <!-- 空状态 -->
    <a-empty v-if="(!fileId || !blob) && !loading" description="暂无预览" />
    <!-- 预览容器 - 始终存在但可能隐藏 -->
    <div
      ref="previewDocContainer"
      class="docx-content"
      :style="{ display: fileId && !loading && blob ? 'block' : 'none' }"
    ></div>
  </div>
</template>
<script setup lang="ts">
import { ref, onMounted, watch, nextTick } from 'vue'
import { message } from 'ant-design-vue'
import { renderAsync } from 'docx-preview'
import type { Options } from 'docx-preview'

defineOptions({
  name: 'PreviewContainer'
})

// 接收父组件传值
const props = defineProps<{
  blob: Blob | null
  fileId?: string
  loading?: boolean
}>()

const previewDocContainer = ref<HTMLElement | null>(null)

// 渲染文档预览
const renderDocPreview = async () => {
  if (!props.fileId || !props.blob) {
    return
  }

  try {
    // 确保DOM更新完成
    await nextTick()

    if (!previewDocContainer.value) {
      console.error('预览容器不存在，fileId:', props.fileId)
      message.error('预览容器不存在，请重试')
      return
    }

    // 清空容器
    previewDocContainer.value.innerHTML = ''

    // 渲染配置选项
    const _options: Options = {
      className: 'custom-docx-render',
      inWrapper: true,
      ignoreWidth: false,
      ignoreHeight: false,
      ignoreFonts: false,
      breakPages: true,
      experimental: false, // 关闭实验性功能以减少错误
      trimXmlDeclaration: true,
      ignoreLastRenderedPageBreak: true,
      useBase64URL: false,
      debug: false,
      hideWrapperOnPrint: false,
      renderHeaders: true,
      renderFooters: true,
      renderChanges: false,
      renderFootnotes: true,
      renderEndnotes: true,
      renderComments: false,
      renderAltChunks: true
    }

    try {
      await renderAsync(props.blob, previewDocContainer.value, undefined, _options)
      message.success('文档加载完成')
    } catch (renderError: any) {
      console.warn('渲染出错，尝试使用简化模式:', renderError.message)
      // 使用简化配置重新渲染
      const simpleOptions: Options = {
        className: 'custom-docx-render',
        inWrapper: true,
        experimental: false,
        debug: false,
        ignoreFonts: true,
        ignoreHeight: true,
        ignoreWidth: true,
        breakPages: true,
        trimXmlDeclaration: true,
        ignoreLastRenderedPageBreak: true,
        useBase64URL: false,
        hideWrapperOnPrint: false,
        renderHeaders: false,
        renderFooters: false,
        renderChanges: false,
        renderFootnotes: false,
        renderEndnotes: false,
        renderComments: false,
        renderAltChunks: false
      }
      await renderAsync(props.blob, previewDocContainer.value, undefined, simpleOptions)
      message.success('文档加载完成（简化模式）')
    }
  } catch (error) {
    console.error('文档加载失败:', error)
    if (previewDocContainer.value) {
      previewDocContainer.value.innerHTML = '文档加载失败'
    }
  }
}

// 监听blob变化，重新渲染预览
watch(
  () => props.blob,
  newBlob => {
    if (newBlob) {
      renderDocPreview()
    }
  }
)

// 组件挂载后，如果已有blob数据则渲染
onMounted(() => {
  if (props.blob && props.fileId) {
    renderDocPreview()
  }
})
</script>
<style lang="less" scoped>
/* 样式保持不变 */
.docx-preview-container {
  padding: 20px;
  max-width: 900px;
  margin: 0 auto;
}

.preview-container {
  margin-top: 20px;
  overflow: hidden;
}

.docx-preview {
  background: #fff;
  padding: 20px;
  border-radius: 4px;
  /* min-height: 500px; */
  // height: 500px;
  max-height: 500px;
  overflow: auto;
  box-shadow: 0 0 0 1px #d9d9d9;
}

:deep(.custom-docx-render) {
  background: white;
  padding: 20px;
  box-shadow: none;
  width: 100% !important;
  max-width: 100% !important;
}

:deep(.docx-page) {
  margin-bottom: 20px;
  box-shadow: 0 0 0 1px #eee;
  padding: 20px;
  background: white;
  page-break-after: always;
}

:deep(table) {
  max-width: 100% !important;
  width: auto !important;
}

:deep(img) {
  max-width: 100% !important;
  height: auto !important;
}

@media (max-width: 768px) {
  .docx-preview-container {
    padding: 10px;
  }

  .docx-preview {
    padding: 10px;
  }

  :deep(.docx-page) {
    padding: 10px;
  }
}

:deep(.custom-docx-render-wrapper) {
  padding: 2px !important;
  background-color: rgb(255, 255, 255);
}

.docx-content {
  width: 100%;
  min-height: 100px;
}
</style>
