<template>
  <div class="page-container">
    <a-card :bordered="false" class="card-container">
      <!-- 按钮区域 -->
      <div class="fixed-btn-area">
        <div class="upload-area">
          <a-upload
            name="file"
            :multiple="false"
            :show-upload-list="false"
            :before-upload="beforeUpload"
            accept=".docx,.doc"
          >
            <a-button :loading="loadingUpload" type="primary">
              <template #icon><upload-outlined /></template>
              上传新文件
            </a-button>
          </a-upload>
          <span class="upload-hint">支持.docx格式</span>
        </div>
        <div class="action-buttons" v-if="currentFileId">
          <a-button 
            v-if="documentContent" 
            @click="saveDocument" 
            :loading="saving"
            type="primary"
          >
            保存文档
          </a-button>
          <a-button 
            v-if="documentContent" 
            @click="resetDocument" 
            :disabled="saving"
          >
            重置文档
          </a-button>
          <a-button
            @click="testUpdateDocx"
            type="primary"
            ghost
          >
            测试修改文档
          </a-button>
        </div>
        <div class="file-title" v-if="currentFileId">
          当前文件：{{ file.filename }}
        </div>
      </div>
      <!-- 可滚动的内容区域 -->
      <div class="scrollable-content">
        <!-- 文档预览 - 双栏布局 -->
        <template v-if="currentFileId">
          <div class="document-stack">
            <!-- 原始文档 -->
            <div class="document-section">
              <a-divider orientation="left" style="font-size: 14px">原始文档</a-divider>
              <div v-if="loadingPreview" class="section-loading">
                <a-spin tip="加载原始文档..." />
              </div>
              <PreviewContainer 
                v-else
                :blob="originalBlob" 
                :fileId="currentFileId" 
                :loading="loadingPreview" 
              />
            </div>
            
            <!-- 处理后文档 -->
            <div class="document-section">
              <a-divider orientation="left" style="font-size: 14px">
                处理后文档
                <a-tag v-if="fileStore.hasModifiedDoc" color="green">已修改</a-tag>
              </a-divider>
              <div v-if="loadingModify" class="section-loading">
                <a-spin tip="加载修改文档..." />
              </div>
              <!-- 使用PreviewContainer组件来统一显示格式 -->
              <PreviewContainer 
                v-else-if="modifiedBlob" 
                :blob="modifiedBlob" 
                :fileId="currentFileId" 
                :loading="loadingModify" 
              />
              <div v-else-if="fileStore.hasModifiedDoc && fileStore.processedContent" class="doc-preview-wrapper">
                <!-- 加载中状态 -->
                <div v-if="converting" class="section-loading">
                  <a-spin tip="正在转换为DOCX格式..." />
                </div>
                <!-- 文本内容显示，添加重试按钮 -->
                <template v-else>
                  <div class="processed-content-actions">
                    <a-button type="primary" size="small" @click="convertTextToDocx" :loading="converting">
                      重试DOCX格式转换
                    </a-button>
                  </div>
                  <div class="modified-content">
                    <pre>{{ fileStore.processedContent }}</pre>
                  </div>
                </template>
              </div>
              <div v-else class="no-modified-doc">
                <p>暂无修改版本，请在聊天中发送"公文纠错"或使用右侧测试功能生成修改版本</p>
              </div>
            </div>
          </div>
        </template>
        
        <!-- 未上传文档时的提示 -->
        <div v-else class="upload-placeholder">
          <upload-outlined style="font-size: 48px; margin-bottom: 16px" />
          <p>请上传.docx文档以开始处理</p>
        </div>
      </div>
    </a-card>
  </div>
</template>
<script setup lang="ts">
import { ref, watch, computed, onMounted, onUnmounted } from 'vue'
import { storeToRefs } from 'pinia'
import { message } from 'ant-design-vue'
import { UploadOutlined } from '@ant-design/icons-vue'
import PreviewContainer from '@/components/Page/FilePage/PreviewContainer.vue'
import { useFileStore } from '@/stores/file'
import { useAuthStore } from '@/stores/auth'
import { useChatStore } from '@/stores/chat'
import type { FileItem } from '@/types/FileType'
import type { ChatItem } from '@/types/ChatType'
import weChatbotService from '@/api/weChatbot'

defineOptions({
  name: 'FilePage'
})

// ------------------------------------------------
const fileStore = useFileStore()
const authStore = useAuthStore()
const chatStore = useChatStore()

const { hasModifiedDoc } = storeToRefs(fileStore)
const file = computed(() => fileStore.currentFile)
const currentFileId = computed(() => fileStore.currentFile.id)
const chat = computed(() => chatStore.currentChat)
const { loadingUpload } = storeToRefs(fileStore)

// ------------------------------------------------
// 状态管理
const loadingPreview = ref<boolean>(false)
const originalBlob = ref<Blob | null>(null)

const loadingModify = ref<boolean>(false)
const modifiedBlob = ref<Blob | null>(null)
const converting = ref<boolean>(false)

// 文档状态 --------------------------------------
const originalContent = ref<string | null>(null)
const documentContent = ref<string | null>(null)
const documentId = ref<string | null>(null)
const saving = ref<boolean>(false)

// ------------------------------------------------
// 获取原始文档预览
const fetchOriginalPreview = async (fileId: string) => {
  if (!fileId) return

  loadingPreview.value = true
  try {
    originalBlob.value = await fileStore.previewFile(fileId)
    message.success('文档获取成功')
  } catch (error) {
    console.error('获取文档失败:', error)
    message.error('获取文档失败')
    originalBlob.value = null
  } finally {
    loadingPreview.value = false
  }
}

// 获取修改后的文档预览
const fetchModifiedPreview = async (file: FileItem, chat: ChatItem) => {
  if (!file.id) return

  loadingModify.value = true
  try {
    // 获取修改后的文档
    modifiedBlob.value = await fileStore.previewModifiedFile(file, chat)
    message.success('修改文档获取成功')
  } catch (error) {
    console.error('获取修改文档失败:', error)
    message.error('获取修改文档失败')
    modifiedBlob.value = null
  } finally {
    loadingModify.value = false
  }
}

// 上传前检查
const beforeUpload = async (file) => {
  const isWord = 
    file.type === 'application/msword' || 
    file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
    /\.(doc|docx)$/.test(file.name.toLowerCase())
  
  if (!isWord) {
    message.error('只能上传Word文档!')
    return false
  }
  
  const isLt10M = file.size / 1024 / 1024 < 10
  if (!isLt10M) {
    message.error('文件大小不能超过10MB!')
    return false
  }
  
  try {
    // 上传文件
    const fileItem = await fileStore.uploadFile({
      userid: authStore.currentUser?.userid || '',
      file: file
    })
    
    message.success(`${file.name} 上传成功，请在聊天框中输入"公文纠错"或"文档润色"等指令处理文档`)
    
    // 更新当前文件
    fileStore.setCurrentFile(fileItem)
    
    // 刷新文件列表
    await fileStore.fetchFileList({
      userid: authStore.currentUser?.userid || '',
      username: authStore.currentUser?.username || ''
    })
  } catch (error) {
    console.error('上传文件失败:', error)
    message.error('上传文件失败')
  }
  
  return false // 阻止默认上传行为
}

// 测试修改文档 ----------------------------------
const testUpdateDocx = async () => {
  message.info('测试修改文档')
  await fetchModifiedPreview(file.value, chat.value)
  // 设置有修改文档的状态
  fileStore.setHasModifiedDoc(true)
}

// 保存文档 --------------------------------------
const saveDocument = async () => {
  if (!documentId.value || !documentContent.value) {
    message.error('没有可保存的文档')
    return
  }
  
  saving.value = true
  try {
    await weChatbotService.saveDocument(
      documentId.value, 
      documentContent.value, 
      'processed_document.docx'
    )
    message.success('文档保存成功')
  } catch (error) {
    console.error('文档保存失败:', error)
    message.error('文档保存失败')
  } finally {
    saving.value = false
  }
}

// 重置文档 --------------------------------------
const resetDocument = () => {
  if (originalContent.value) {
    documentContent.value = originalContent.value
    message.info('文档已重置')
  }
}

// 监听文档更新事件 --------------------------------------
const handleDocumentUpdate = (event: CustomEvent) => {
  console.log('收到文档更新事件:', event.detail);
  if (event.detail && event.detail.content) {
    documentContent.value = event.detail.content;
    // 更新修改文档预览
    if (file.value && chat.value) {
      message.success('文档已更新，处理后内容自动转换为DOCX格式中...');
      // 确保fileStore.hasModifiedDoc为true
      if (!fileStore.hasModifiedDoc) {
        fileStore.setHasModifiedDoc(true);
      }
      
      // 自动转换为DOCX格式
      autoConvertToDocx();
    }
  }
}

// 自动将文本内容转换为DOCX格式
const autoConvertToDocx = async () => {
  if (!fileStore.processedContent || !currentFileId.value) {
    console.warn('没有可转换的文档内容');
    return;
  }
  
  converting.value = true;
  try {
    // 调用后端API将文本内容转换为DOCX
    const response = await weChatbotService.convertTextToDocx(
      fileStore.processedContent,
      `processed_${file.value.filename}`
    );
    
    // 获取返回的Blob数据
    if (response) {
      modifiedBlob.value = response;
      message.success('文档已自动转换为DOCX格式');
    }
  } catch (error) {
    console.error('转换文档失败:', error);
    message.error('DOCX格式转换失败，显示为文本格式');
  } finally {
    converting.value = false;
  }
}

// 将文本内容转换为DOCX格式 (保留为手动转换备用)
const convertTextToDocx = async () => {
  if (!fileStore.processedContent || !currentFileId.value) {
    message.error('没有可转换的文档内容');
    return;
  }
  
  converting.value = true;
  try {
    // 调用后端API将文本内容转换为DOCX
    const response = await weChatbotService.convertTextToDocx(
      fileStore.processedContent,
      `processed_${file.value.filename}`
    );
    
    // 获取返回的Blob数据
    if (response) {
      modifiedBlob.value = response;
      message.success('文档已转换为DOCX格式');
    }
  } catch (error) {
    console.error('转换文档失败:', error);
    message.error('转换文档失败，仍使用文本格式显示');
  } finally {
    converting.value = false;
  }
}

// ------------------------------------------------
// 监听当前fileID变化
watch(
  () => currentFileId.value,
  async newFileId => {
    if (newFileId) {
      message.info(`当前文件: ${file.value.filename}`)
      // 获取原始文档预览
      await fetchOriginalPreview(newFileId)
      // 如果有修改的文档，获取修改后的预览
      if (hasModifiedDoc.value) {
        await fetchModifiedPreview(file.value, chat.value)
      } else {
        // 重置修改文档状态
        modifiedBlob.value = null
      }
    } else {
      // 重置状态
      originalBlob.value = null
      modifiedBlob.value = null
    }
  },
  { immediate: true }
)

// 组件挂载和卸载时的事件监听 --------------------------------------
onMounted(() => {
  window.addEventListener('processed-document-updated', handleDocumentUpdate as EventListener)
})

onUnmounted(() => {
  window.removeEventListener('processed-document-updated', handleDocumentUpdate as EventListener)
})
</script>
<style lang="less" scoped>
.page-container {
  margin: 20px;
}
.card-container {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}
.fixed-btn-area {
  /* 固定按钮区域 */
  flex-shrink: 0;
  position: sticky;
  top: 0;
  background-color: white;
  z-index: 10;
  padding: 10px 0;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
}
.upload-area {
  display: flex;
  align-items: center;
}
.upload-hint {
  margin-left: 10px;
  color: #999;
  font-size: 12px;
}
.action-buttons {
  display: flex;
  gap: 8px;
}
.file-title {
  font-size: 16px;
  font-weight: bold;
  color: #1890ff;
}
.scrollable-content {
  /* 可滚动内容区域 */
  flex: 1;
  overflow-y: auto;
  padding: 10px;
}
.document-stack {
  display: flex;
  flex-direction: column;
  gap: 20px;
  margin-top: 16px;
}
.document-section {
  width: 100%;
  border: 1px solid #f0f0f0;
  border-radius: 4px;
  padding: 16px;
  background-color: #fafafa;
  min-height: 400px;
  display: flex;
  flex-direction: column;
}
.section-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 300px;
}
.no-modified-doc {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 300px;
  color: #999;
  text-align: center;
  padding: 0 20px;
}
.doc-preview-wrapper {
  flex: 1;
}
.processed-content-actions {
  margin-bottom: 16px;
  display: flex;
  justify-content: flex-end;
}
.modified-content {
  padding: 16px;
  background-color: #f9f9f9;
  border: 1px solid #e8e8e8;
  border-radius: 4px;
  max-height: 500px;
  overflow-y: auto;
  white-space: pre-wrap;
  word-break: break-word;
}
.upload-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 300px;
  color: #999;
  border: 2px dashed #e9e9e9;
  border-radius: 8px;
  background-color: #fafafa;
}

/* 响应式布局 */
@media (max-width: 768px) {
  .document-stack {
    flex-direction: column;
  }
  .document-section {
    min-height: 300px;
  }
}
</style>
