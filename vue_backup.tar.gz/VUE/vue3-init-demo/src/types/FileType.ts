export interface FileListRequest {
  userid: string
  username: string
}

// 文件Item
export interface FileItem {
  id: string
  filename: string
  fileuuid: string
  fileurl: string
  updatetime: string
  userid: string
}

// 上传文件参数
export interface FileFormData {
  userid: string
  file: File
}

