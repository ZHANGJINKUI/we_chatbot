import { ref } from 'vue'
import { defineStore } from 'pinia'
import type { ChatListRequest, ChatItem, Message } from '@/types/ChatType'
import { fetchChatListApi, deleteChatApi } from '@/api/chat'
import { v4 as uuidv4 } from 'uuid'

export const useChatStore = defineStore('chat', () => {
  const chatListData = ref<ChatItem[]>([])
  const loadingFetchList = ref<boolean>(false)

  // 请求聊天会话列表
  const fetchChatList = async (params: ChatListRequest) => {
    try {
      loadingFetchList.value = true
      chatListData.value = [] // 清空数据
      const data = await fetchChatListApi(params)
      if (data && data.length > 0) chatListData.value = data
    } catch (error) {
      console.error('fetchChatListApi失败:', error)
    } finally {
      loadingFetchList.value = false
    }
  }

  // ---------------------------------------------
  const currentChat = ref<ChatItem>({
    id: '',
    title: '',
    messages: []
  })
  const currentChatId = ref<string>('')

  // 设置当前聊天
  const setCurrentChat = (chat: ChatItem) => {
    currentChat.value = chat
    currentChatId.value = chat.id
  }

  // 创建新聊天
  const createNewChat = () => {
    const newChatId = uuidv4()
    const systemMessage: Message = {
      role: 'system',
      id: `${newChatId}-system-${Date.now()}`,
      createAt: Date.now(),
      content: "I'm here to assist you with any questions or tasks.",
      status: 'complete'
    }
    
    const newChat: ChatItem = {
      id: newChatId,
      title: '新对话',
      messages: [systemMessage]
    }
    
    // 添加到列表
    chatListData.value.unshift(newChat)
    // 设置为当前聊天
    setCurrentChat(newChat)
    
    console.log('创建新对话:', newChat)
    return newChat
  }

  // 更新当前聊天
  const updateCurrentChat = (chatData: Partial<ChatItem>) => {
    if (!currentChat.value.id) {
      console.error('No current chat to update')
      return
    }
    
    // 更新当前聊天
    currentChat.value = {
      ...currentChat.value,
      ...chatData
    }
    
    // 同时更新列表中对应的聊天
    const index = chatListData.value.findIndex(chat => chat.id === currentChat.value.id)
    if (index !== -1) {
      chatListData.value[index] = currentChat.value
    }
    
    console.log('更新当前聊天:', currentChat.value)
  }

  // ---------------------------------------------
  // 删除聊天
  const deleteChat = async (chatId: string) => {
    try {
      await deleteChatApi(chatId)
      // 如果删除的是当前选中的聊天，清空选中状态
      if (currentChat.value.id === chatId) {
        currentChat.value = {
          id: '',
          title: '',
          messages: []
        }
        currentChatId.value = ''
      }
    } catch (error) {
      console.error('Failed to delete chat:', error)
    }
  }

  return {
    chatListData,
    loadingFetchList,
    fetchChatList,
    currentChat,
    currentChatId,
    setCurrentChat,
    createNewChat,
    updateCurrentChat,
    deleteChat
  }
})
