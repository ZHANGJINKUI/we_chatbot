import { ref } from 'vue'
import { defineStore } from 'pinia'
import type { UploadProps } from 'ant-design-vue'
import type { FileListRequest, FileItem, FileFormData } from '@/types/FileType'
import {
  fetchFileListApi,
  deleteFileApi,
  uploadFileApi,
  downloadFileApi,
  previewFileApi,
  previewModifiedFileApi,
  confirmModifyApi
} from '@/api/file'
import type { ChatItem } from '@/types/ChatType'

export const useFileStore = defineStore('file', () => {
  const fileListData = ref<FileItem[]>([])
  const loadingFetchList = ref<boolean>(false)
  // 请求文件列表
  const fetchFileList = async (params: FileListRequest) => {
    try {
      loadingFetchList.value = true
      fileListData.value = [] // 清空数据
      const data = await fetchFileListApi(params)
      if (data && data.length > 0) fileListData.value = data
    } catch (error) {
      console.error('fetchFileListApi失败:', error)
    } finally {
      loadingFetchList.value = false
    }
  }
  // ---------------------------------------------
  const currentFile = ref<FileItem>({
    id: '',
    userid: '',
    filename: '',
    fileuuid: '',
    fileurl: '',
    updatetime: ''
  })

  // 设置当前文件
  const setCurrentFile = (file: FileItem) => {
    currentFile.value = file
  }
  // ---------------------------------------------
  // 删除文件
  const deleteFile = async (fileId: string) => {
    try {
      await deleteFileApi(fileId)
      // 如果删除的是当前选中的文件，清空选中状态
      if (currentFile.value.id === fileId) {
        currentFile.value = {
          id: '',
          userid: '',
          filename: '',
          fileuuid: '',
          fileurl: '',
          updatetime: ''
        }
      }
    } catch (error) {
      console.error('Failed to delete file:', error)
    }
  }
  // ------------------------------------------------------
  const loadingUpload = ref<boolean>(false)
  const uploadFileList = ref<UploadProps['fileList'] | undefined>([])
  // 文件上传
  const uploadFile: (params: FileFormData) => Promise<FileItem> = async (params: FileFormData) => {
    try {
      loadingUpload.value = true
      const formData = new FormData()
      formData.append('userid', params.userid)
      formData.append('file', params.file) // 单文件
      // params.file.forEach(f => { // 多文件
      //   formData.append('file', f)
      // })
      return await uploadFileApi(formData)
    } catch (err) {
      console.error('Failed to upload file:', err)
      throw err
    } finally {
      loadingUpload.value = false
    }
  }
  // ------------------------------------------------------
  const loadingDownload = ref<boolean>(false)
  // 文件下载
  const downloadFile = async (_id: string) => {
    try {
      loadingDownload.value = true
      const response = await downloadFileApi({ id: _id })
      const url = window.URL.createObjectURL(new Blob([response.data]))

      const filename = currentFile.value.filename
      // 生成毫秒级时间戳
      const timestamp = new Date().getTime()
      // 分割文件名和扩展名
      const lastDotIndex = filename.lastIndexOf('.')
      const name = lastDotIndex !== -1 ? filename.substring(0, lastDotIndex) : filename
      const extension = lastDotIndex !== -1 ? filename.substring(lastDotIndex) : ''
      // 组合新文件名：原文件名_时间戳.扩展名
      const newFilename = `${name}_${timestamp}${extension}`

      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', newFilename) // 设置带时间戳的文件名
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (err) {
      console.error('Failed to download file:', err)
      throw err
    } finally {
      loadingDownload.value = false
    }
  }
  // ------------------------------------------------------
  // 文件预览
  const previewFile = async (_id: string) => {
    try {
      const response = await previewFileApi({ id: _id })
      return response.data // 返回blob数据
    } catch (err) {
      console.error('Failed to preview file:', err)
    }
  }

  // 修改文件预览
  const previewModifiedFile = async (file: FileItem, chat: ChatItem) => {
    try {
      const response = await previewModifiedFileApi({ file, chat })
      return response.data // 返回blob数据
    } catch (err) {
      console.error('Failed to preview modified file:', err)
    }
  }
  // ------------------------------------------------------
  // 文档修改状态
  const hasModifiedDoc = ref<boolean>(false)
  
  // 设置文档修改状态
  const setHasModifiedDoc = (status: boolean) => {
    hasModifiedDoc.value = status
  }
  // ------------------------------------------------------
  // 确认修改
  const confirmModify = async (file: FileItem, chat: ChatItem) => {
    try {
      await confirmModifyApi({ file, chat })
      // 重置状态
      hasModifiedDoc.value = false
    } catch (err) {
      console.error('Failed to confirm modify:', err)
    }
  }
  // ------------------------------------------------------
  // 处理后的文档内容
  const processedContent = ref<string>('')
  
  // 更新处理后的文档内容
  const updateProcessedContent = (content: string) => {
    console.log('更新处理后的文档内容，长度:', content.length)
    processedContent.value = content
    // 设置文档已修改状态
    hasModifiedDoc.value = true
  }
  // ------------------------------------------------------
  return {
    fileListData,
    loadingFetchList,
    fetchFileList,
    currentFile,
    setCurrentFile,
    deleteFile,
    loadingUpload,
    uploadFile,
    uploadFileList,
    loadingDownload,
    downloadFile,
    previewFile,
    previewModifiedFile,
    hasModifiedDoc,
    setHasModifiedDoc,
    confirmModify,
    processedContent,
    updateProcessedContent
  }
})
