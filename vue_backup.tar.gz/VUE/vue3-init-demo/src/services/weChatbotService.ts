import axios from 'axios'
import { useFileStore } from '@/stores/file';

// 创建一个没有baseURL的axios实例，这样请求会通过Vite代理
const axiosInstance = axios.create({
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
});

/**
 * 检查消息是否与文档处理相关
 * @param message 用户消息
 * @returns boolean 是否与文档处理相关
 */
const isDocumentRelatedQuery = (message: string): boolean => {
  const docKeywords = [
    '文档', '公文', '纠错', '润色', '文件', 
    '上传', '处理', '修改', '校对', '检查',
    '改进', '修复', '纠正', '审核', '改良'
  ];
  
  return docKeywords.some(keyword => message.includes(keyword));
}

export const sendChatRequest = async (
  message: string,
  chatHistory: any[],
  onContent: (content: string) => void,
  onComplete: () => void,
  onError: (error: any) => void
) => {
  try {
    console.log('开始发送消息:', message);
    
    // 检查消息是否与文档处理相关
    const isDocRequest = isDocumentRelatedQuery(message);
    const fileStore = useFileStore();
    const hasUploadedDoc = fileStore.currentFile && fileStore.currentFile.id;
    
    // 构建请求参数
    const params = new URLSearchParams();
    params.append('message', message);
    params.append('chat_history', JSON.stringify(chatHistory.map(msg => ({
      role: msg.role,
      content: msg.content
    }))));

    // 如果是文档处理请求并且有上传的文档，添加文件ID
    if (isDocRequest && hasUploadedDoc && fileStore.currentFile && fileStore.currentFile.id) {
      console.log('检测到文档相关查询，添加文件ID:', fileStore.currentFile.id);
      params.append('file_id', fileStore.currentFile.id);
    }
    
    // 直接使用GET请求
    console.log('构建请求URL:', `/api/stream-chat?${params.toString().substring(0, 100)}...`);
    
    const response = await axiosInstance.get(`/api/stream-chat?${params.toString()}`, {
      headers: { 'Accept': 'text/event-stream' },
      responseType: 'text'
    });
    
    console.log('收到响应:', response.status);
    
    // 处理响应数据
    const text = response.data || '';
    const messages = text.split('\n\n');
    console.log(`接收到 ${messages.length} 个SSE消息`);
    
    // 收集到的完整内容
    let fullContent = '';
    
    // 处理每个消息
    for (const msg of messages) {
      if (!msg || !msg.trim()) continue;
      
      if (msg.startsWith('data: ')) {
        const data = msg.substring(6).trim();
        
        if (data === 'end') {
          console.log('检测到结束标记');
          break;
        }
        
        try {
          const parsedData = JSON.parse(data);
          console.log('解析的数据:', parsedData);
          
          // 更新内容
          if (parsedData && parsedData.content) {
            fullContent = parsedData.content;
            onContent(fullContent);
          }
          
          // 处理文档内容
          if (parsedData && parsedData.processed_document) {
            console.log('收到处理后的文档内容，长度:', parsedData.processed_document.length);
            if (fileStore.currentFile && fileStore.currentFile.id) {
              fileStore.setHasModifiedDoc(true);
              fileStore.updateProcessedContent(parsedData.processed_document);
              window.dispatchEvent(new CustomEvent('processed-document-updated', {
                detail: { content: parsedData.processed_document }
              }));
              
              // 添加自动转换文档功能的日志
              console.log('已触发文档更新事件，文档内容将自动转换为DOCX格式');
            }
          }
        } catch (error) {
          console.error('解析消息失败:', error);
        }
      }
    }
    
    // 完成回调
    onComplete();
    
  } catch (error) {
    console.error('请求错误:', error);
    onError(error);
  }
};

export const healthCheck = async (): Promise<boolean> => {
  try {
    console.log('正在进行健康检查...');
    const response = await axiosInstance.get('/api/health-check');
    console.log('健康检查响应:', response.status);
    return response.status === 200;
  } catch (error) {
    console.error('健康检查失败:', error);
    return false;
  }
};

export const downloadProcessedDocument = async (chatId: string): Promise<Blob> => {
  try {
    const response = await axiosInstance.get('/api/download-result', {
      responseType: 'blob',
      params: { chatId }
    });
    console.log('下载文档响应:', response.status);
    return response.data;
  } catch (error) {
    console.error('下载文档失败:', error);
    throw error;
  }
};

/**
 * 将文本内容转换为DOCX格式
 * @param textContent 文本内容
 * @param filename 文件名
 * @returns Blob 转换后的DOCX文件Blob对象
 */
export const convertTextToDocx = async (textContent: string, filename: string): Promise<Blob> => {
  try {
    console.log('开始转换文本到DOCX格式...');
    const response = await axiosInstance.post('/api/convert-text-to-docx', {
      text_content: textContent,
      filename: filename
    }, {
      responseType: 'blob'
    });
    
    console.log('转换文本到DOCX响应:', response.status);
    return response.data;
  } catch (error) {
    console.error('转换文本到DOCX失败:', error);
    throw error;
  }
}; 