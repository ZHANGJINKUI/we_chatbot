import axios from 'axios'

interface ChatMessage {
  role: string;
  id?: string;
  createAt?: number;
  content: string;
  status?: string;
}

interface DocumentInfo {
  document_id: string;
  content: string;
  original_content?: string;
}

// 创建与we_chatbot通信的服务
const weChatbotService = {
  // 上传文档
  async uploadDocument(file: File): Promise<DocumentInfo> {
    const formData = new FormData()
    formData.append('file', file)
    const response = await axios.post('/api/upload-document', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    return response.data
  },

  // 发送聊天消息（支持文档处理）
  async sendChatMessage(message: string, documentContent: string | null = null, chatHistory: ChatMessage[] = []) {
    // 将聊天历史转换为API需要的格式
    const formattedHistory = this.formatMessagesForAPI(chatHistory)
    
    const response = await axios.post('/api/chat', {
      message,
      document_content: documentContent,
      chat_history: formattedHistory
    })
    return response.data
  },

  // 用于处理流式聊天响应
  async streamChatResponse(message: string, documentContent: string | null = null, chatHistory: ChatMessage[] = [], onUpdate: (content: string) => void, onComplete: () => void) {
    try {
      // 准备聊天历史
      const formattedHistory = this.formatMessagesForAPI(chatHistory)
      
      // 创建EventSource连接
      const queryParams = new URLSearchParams({
        message,
        ...(documentContent && { document_content: documentContent }),
        chat_history: JSON.stringify(formattedHistory)
      }).toString()
      
      const eventSource = new EventSource(`/api/stream-chat?${queryParams}`)
      
      eventSource.onmessage = (event) => {
        let response = event.data
        if (response === 'end') {
          eventSource.close()
          onComplete()
          return
        }
        
        try {
          // 尝试解析JSON响应
          const parsedResponse = JSON.parse(response)
          
          // 如果有文档处理结果，触发文档更新事件
          if (parsedResponse.processed_document) {
            window.dispatchEvent(new CustomEvent('document-updated', { 
              detail: { content: parsedResponse.processed_document } 
            }))
          }
          
          // 如果有内容更新，调用回调
          if (parsedResponse.content) {
            onUpdate(parsedResponse.content)
          }
        } catch (e) {
          // 如果不是JSON，直接使用文本
          onUpdate(response)
        }
      }
      
      eventSource.onerror = (error) => {
        console.error('EventSource error:', error)
        eventSource.close()
        onComplete()
      }
      
      // 返回一个用于清理的函数
      return () => {
        eventSource.close()
      }
    } catch (error) {
      console.error('Error in stream chat:', error)
      onComplete()
      return () => {}
    }
  },

  // 保存文档
  async saveDocument(documentId: string, content: string, filename: string = 'processed_document.docx') {
    const response = await axios.post('/api/save-document', {
      document_id: documentId,
      content,
      filename
    })
    return response.data
  },

  // 健康检查
  async checkHealth() {
    try {
      const response = await axios.get('/api/health-check')
      return true
    } catch (error) {
      console.error('Server connection check failed:', error)
      return false
    }
  },

  // 将Chat组件中的消息转换为API需要的格式
  formatMessagesForAPI(messages: ChatMessage[]) {
    return messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }))
  }
}

export default weChatbotService 