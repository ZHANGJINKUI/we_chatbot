import http from '@/utils/http'
import type { ChatListRequest, ChatItem } from '@/types/ChatType'
import axios from 'axios'

/** 请求对话列表
 * @param userid
 * @param username
 * **/
export const fetchChatListApi = (params: ChatListRequest): Promise<ChatItem[]> => {
  return http.post('/chat/list', params)
}

/** 删除文件
 * @param id
 * **/
export const deleteChatApi = (id: string) => {
  return http.delete(`/chat/delete/${id}`);
}

interface ChatMessage {
  role: string;
  id: string;
  createAt: number;
  content: string;
  status: string;
}

// 创建与we_chatbot通信的服务
const chatService = {
  // 上传文档
  async uploadDocument(file: File) {
    const formData = new FormData()
    formData.append('file', file)
    const response = await axios.post('/api/upload-document', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    return response.data
  },

  // 发送聊天消息（支持文档处理）
  async sendChatMessage(message: string, documentContent: string | null = null, chatHistory: any[] = []) {
    const response = await axios.post('/api/chat', {
      message,
      document_content: documentContent,
      chat_history: chatHistory
    })
    return response.data
  },

  // 保存文档
  async saveDocument(documentId: string, content: string, filename: string = 'processed_document.docx') {
    const response = await axios.post('/api/save-document', {
      document_id: documentId,
      content,
      filename
    })
    return response.data
  },

  // 健康检查
  async checkHealth() {
    try {
      const response = await axios.get('/api/health-check')
      return true
    } catch (error) {
      console.error('Server connection check failed:', error)
      return false
    }
  },

  // 将Chat组件中的消息转换为API需要的格式
  formatMessagesForAPI(messages: ChatMessage[]) {
    return messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }))
  }
}

export default chatService

