import http from '@/utils/http'
import type { FileListRequest, FileItem } from '@/types/FileType'
import type { ChatItem } from '@/types/ChatType'

/** 请求文件列表
 * @param userid
 * @param username
 * **/
export const fetchFileListApi = (params: FileListRequest): Promise<FileItem[]> => {
  return http.post('/file/list', params)
}

/** 删除文件
 * @param id
 * **/
export const deleteFileApi = (id: string) => {
  return http.delete(`/file/delete/${id}`)
}

/** 上传文件
 * @param formData
 *  - userid: string
 *  - file: File
 * **/
export const uploadFileApi = (formData: FormData): Promise<FileItem> => {
  return http.post('/file/upload', formData)
}

/** 请求文件预览
 *  @param id: string 文件id
 */
export const previewFileApi = (params: { id: string }) => {
  return http.get(`/file/preview`, params, { responseType: 'blob' })
}

/** 请求修改后的文件预览
 *  @param file: FileItem
 *  @param chat: ChatItem
 */
export const previewModifiedFileApi = (params: { file: FileItem; chat: ChatItem }) => {
  return http.post(`/file/modified-preview`, params, { responseType: 'blob' })
}

/** 确认修改
 *  @param file: FileItem
 *  @param chat: ChatItem
 */
export const confirmModifyApi = (params: { file: FileItem; chat: ChatItem }) => {
  return http.post(`/file/confirm-modify`, params)
}

/**
 * 下载文件
 *  @param id: string 文件id
 */
export const downloadFileApi = (params: { id: string }) => {
  return http.get(`/file/download`, params, { responseType: 'blob' })
}
