import type { RouteRecordRaw } from 'vue-router'
import BasicLayout from '@/layouts/BasicLayout.vue'

const routes: RouteRecordRaw[] = [
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import(/* webpackChunkName: "login" */ '@/views/LoginView.vue'),
    meta: {
      title: '登录',
      requiresAuth: false
    }
  },
  {
    path: '/direct-test',
    name: 'DirectTest',
    component: () => import(/* webpackChunkName: "direct-test" */ '@/views/test/DirectTestView.vue'),
    meta: {
      title: '直接测试页面',
      requiresAuth: false
    }
  },
  {
    path: '/auth',
    component: BasicLayout,
    redirect: '/auth/home',
    children: [
      {
        path: 'home',
        name: 'Home',
        component: () => import(/* webpackChunkName: "home" */ '@/views/HomeView.vue'),
        meta: {
          title: '首页',
          requiresAuth: true
        }
      },
      {
        path: 'test',
        name: 'Test',
        component: () => import(/* webpackChunkName: "test" */ '@/views/test/TestView.vue'),
        meta: {
          title: '测试页面',
          requiresAuth: false
        }
      }
    ]
  }
]

export default routes
