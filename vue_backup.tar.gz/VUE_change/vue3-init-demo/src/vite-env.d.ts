/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_BASE_URL: string
  readonly VITE_BASE_URL_DEV: string
  // 可以添加更多环境变量的类型定义
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
