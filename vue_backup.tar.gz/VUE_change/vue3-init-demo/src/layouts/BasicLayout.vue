<template>
  <div style="display: flex; min-height: 100vh;">
    <!-- 简化版侧边栏 - 仅显示基本内容 -->
    <div style="width: 240px; background-color: #fff; border-right: 1px solid #f0f0f0; padding: 16px;">
      <h2 style="margin-bottom: 20px; text-align: center;">智能公文助手</h2>
      
      <div style="margin-bottom: 20px;">
        <h3 style="margin-bottom: 10px;">文件列表</h3>
        <ul style="padding-left: 20px;">
          <li>示例文件 1</li>
          <li>示例文件 2</li>
        </ul>
      </div>
      
      <div style="margin-bottom: 20px;">
        <h3 style="margin-bottom: 10px;">历史对话</h3>
        <ul style="padding-left: 20px;">
          <li>对话 1</li>
          <li>对话 2</li>
        </ul>
      </div>
    </div>
    
    <!-- 主内容区 - 确保router-view正常显示 -->
    <div style="flex: 1; background-color: #f6f6f6; padding: 20px; overflow-y: auto;">
      <router-view />
    </div>
  </div>
</template>

<script setup>
// 简化版布局，无需复杂逻辑
</script>
