<template>
  <div style="padding: 20px; max-width: 800px; margin: 0 auto;">
    <h1 style="color: #333; text-align: center;">基础测试页面</h1>
    <p style="text-align: center;">如果您能看到此内容，则Vue渲染正常工作</p>
    
    <div style="margin-top: 20px; border: 1px solid #eee; border-radius: 8px; padding: 20px;">
      <button @click="goToLogin" style="padding: 10px 20px; background: #1890ff; color: white; border: none; border-radius: 4px; cursor: pointer; margin-right: 10px;">
        登录页
      </button>
      <button @click="goToHome" style="padding: 10px 20px; background: #52c41a; color: white; border: none; border-radius: 4px; cursor: pointer; margin-right: 10px;">
        首页
      </button>
      <button @click="goToDirectTest" style="padding: 10px 20px; background: #fa8c16; color: white; border: none; border-radius: 4px; cursor: pointer;">
        测试页
      </button>

      <div style="margin-top: 30px;">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

const goToLogin = () => {
  router.push('/login')
}

const goToHome = () => {
  router.push('/auth/home')
}

const goToDirectTest = () => {
  router.push('/direct-test')
}
</script>

<style>
</style>