<template>
  <div class="page-container">
    <a-card :bordered="false" class="card-container">
      <!-- 按钮区域 -->
      <div class="fixed-btn-area">
        <div class="upload-area">
          <a-upload
            name="file"
            :multiple="false"
            :show-upload-list="false"
            :before-upload="beforeUpload"
            :custom-request="customRequest"
            accept=".docx"
          >
            <a-button :loading="uploading" type="primary">
              <upload-outlined />
              上传文档
            </a-button>
          </a-upload>
          <span class="upload-hint">支持.docx格式</span>
        </div>
        <div class="action-buttons">
          <a-button 
            v-if="documentContent" 
            @click="saveDocument" 
            :loading="saving"
            type="primary"
          >
            保存文档
          </a-button>
          <a-button 
            v-if="documentContent" 
            @click="resetDocument" 
            :disabled="saving"
          >
            重置文档
          </a-button>
        </div>
      </div>
      <!-- 可滚动的内容区域 -->
      <div class="scrollable-content">
        <!-- 原始文档内容 -->
        <div v-if="originalContent" class="document-container">
          <a-divider orientation="left" style="font-size: 12px">原始文档</a-divider>
          <div class="document-content">
            <pre>{{ originalContent }}</pre>
          </div>
        </div>
        
        <!-- 处理后的文档内容 -->
        <div v-if="documentContent" class="document-container">
          <a-divider orientation="left" style="font-size: 12px">处理后文档</a-divider>
          <div class="document-content">
            <pre>{{ documentContent }}</pre>
          </div>
        </div>
        
        <!-- 未上传文档时的提示 -->
        <div v-if="!originalContent && !documentContent" class="upload-placeholder">
          <upload-outlined style="font-size: 48px; margin-bottom: 16px" />
          <p>请上传.docx文档以开始处理</p>
        </div>
      </div>
    </a-card>
  </div>
</template>
<script setup lang="ts">
import { ref, watch, computed, onMounted, onUnmounted } from 'vue'
import { storeToRefs } from 'pinia'
import { message } from 'ant-design-vue'
import { UploadOutlined } from '@ant-design/icons-vue'
import BtnController from '@/components/Page/FilePage/BtnController.vue'
import PreviewContainer from '@/components/Page/FilePage/PreviewContainer.vue'
import { useFileStore } from '@/stores/file'
import { useChatStore } from '@/stores/chat'
import type { FileItem } from '@/types/FileType'
import type { ChatItem } from '@/types/ChatType'
import weChatbotService from '@/api/weChatbot'

defineOptions({
  name: 'FilePage'
})

// ------------------------------------------------
const fileStore = useFileStore()
const chatStore = useChatStore()

const { hasModifiedDoc } = storeToRefs(fileStore)
const file = computed(() => fileStore.currentFile)
const currentFileId = computed(() => fileStore.currentFile.id)

const chat = computed(() => chatStore.currentChat)
// ------------------------------------------------
// 状态管理
const loadingPreview = ref<boolean>(false)
const originalBlob = ref<Blob | null>(null)

const loadingModify = ref<boolean>(false)
const modifiedBlob = ref<Blob | null>(null)

// 文档状态 --------------------------------------
const originalContent = ref<string | null>(null)
const documentContent = ref<string | null>(null)
const documentId = ref<string | null>(null)
const uploading = ref<boolean>(false)
const saving = ref<boolean>(false)
// ------------------------------------------------
// 获取原始文档预览
const fetchOriginalPreview = async (fileId: string) => {
  if (!fileId) return

  loadingPreview.value = true
  try {
    originalBlob.value = await fileStore.previewFile(fileId)
    message.success('原始文档获取成功')
  } catch (error) {
    console.error('获取原始文档失败:', error)
    message.error('获取原始文档失败')
    originalBlob.value = null
  } finally {
    loadingPreview.value = false
  }
}

// 获取修改后的文档预览
const fetchModifiedPreview = async (file: FileItem, chat: ChatItem) => {
  if (!file.id) return

  loadingModify.value = true
  try {
    // 这里应该是获取修改后的文档，目前使用原始文档作为示例
    // 实际应用中可能需要调用不同的API或传递不同的参数
    modifiedBlob.value = await fileStore.previewModifiedFile(file, chat)
    message.success('修改文档获取成功')
  } catch (error) {
    console.error('获取修改文档失败:', error)
    message.error('获取修改文档失败')
    modifiedBlob.value = null
  } finally {
    loadingModify.value = false
  }
}

// 确认修改
const confirmModify = async () => {
  try {
    // 调用确认修改API
    await fileStore.confirmModify(file.value, chat.value)
    // 重新加载原始文档
    if (currentFileId.value) {
      await fetchOriginalPreview(currentFileId.value)
    }
    // 清空修改文档
    modifiedBlob.value = null
    // 重置状态
    fileStore.setHasModifiedDoc(false)
    message.success('已确认修改')
  } catch (error) {
    console.error('确认修改失败:', error)
    message.error('确认修改失败')
  }
}

// 重置修改文档
const resetModifiedDoc = async () => {
  loadingModify.value = true
  try {
    // 清空修改文档
    modifiedBlob.value = null
    // 重置状态
    fileStore.setHasModifiedDoc(false)
    message.success('已重置修改')
  } catch (error) {
    console.error('重置失败:', error)
    message.error('重置失败')
  } finally {
    loadingModify.value = false
  }
}
// ------------------------------------------------
// 监听当前fileID变化
watch(
  () => currentFileId.value,
  async newFileId => {
    if (newFileId) {
      message.info(`当前文件ID: ${newFileId}`)
      // 获取原始文档预览
      await fetchOriginalPreview(newFileId)
      // 重置修改文档状态
      modifiedBlob.value = null
      fileStore.setHasModifiedDoc(false)
    } else {
      // 重置状态
      originalBlob.value = null
      modifiedBlob.value = null
      fileStore.setHasModifiedDoc(false)
    }
  },
  { immediate: true }
)
// -----------------------------------------
const testUpdateDocx = async () => {
  message.info('测试修改文档')
  await fetchModifiedPreview(file.value, chat.value)
  // 设置有修改文档的状态
  fileStore.setHasModifiedDoc(true)
}

// 文档上传 --------------------------------------
const beforeUpload = (file: File) => {
  const isDocx = file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  if (!isDocx) {
    message.error('只能上传 .docx 文件!')
  }
  return isDocx || Upload.LIST_IGNORE
}

const customRequest = async (options: any) => {
  const { file, onSuccess, onError } = options
  uploading.value = true

  try {
    // 调用we_chatbot的文档上传API
    const response = await weChatbotService.uploadDocument(file)
    
    // 设置文档内容和ID
    originalContent.value = response.content
    documentContent.value = response.content
    documentId.value = response.document_id
    
    message.success('文档上传成功')
    onSuccess(response, file)
  } catch (error) {
    console.error('文档上传失败:', error)
    message.error('文档上传失败')
    onError(error)
  } finally {
    uploading.value = false
  }
}

// 保存文档 --------------------------------------
const saveDocument = async () => {
  if (!documentId.value || !documentContent.value) {
    message.error('没有可保存的文档')
    return
  }
  
  saving.value = true
  try {
    await weChatbotService.saveDocument(
      documentId.value, 
      documentContent.value, 
      'processed_document.docx'
    )
    message.success('文档保存成功')
  } catch (error) {
    console.error('文档保存失败:', error)
    message.error('文档保存失败')
  } finally {
    saving.value = false
  }
}

// 重置文档 --------------------------------------
const resetDocument = () => {
  if (originalContent.value) {
    documentContent.value = originalContent.value
    message.info('文档已重置')
  }
}

// 监听文档更新事件 --------------------------------------
const handleDocumentUpdate = (event: CustomEvent) => {
  if (event.detail && event.detail.content) {
    documentContent.value = event.detail.content
  }
}

// 组件挂载和卸载时的事件监听 --------------------------------------
onMounted(() => {
  window.addEventListener('document-updated', handleDocumentUpdate as EventListener)
})

onUnmounted(() => {
  window.removeEventListener('document-updated', handleDocumentUpdate as EventListener)
})
</script>
<style lang="less" scoped>
.page-container {
  // background-color: rgb(218, 183, 233);
  margin: 20px; /* Change margin to padding, but remove bottom padding */
}
.card-container {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}
.fixed-btn-area {
  /* 固定按钮区域 */
  flex-shrink: 0;
  // margin-bottom: 10px;
  position: sticky;
  top: 0;
  background-color: white;
  z-index: 10;
  padding: 10px 0;
}
.scrollable-content {
  /* 可滚动内容区域 */
  flex: 1;
  overflow-y: auto;
  // padding-right: 10px; /* 为滚动条留出空间 */
  padding: 10px;
}
.upload-area {
  display: flex;
  align-items: center;
  margin-bottom: 16px;
}

.upload-hint {
  margin-left: 8px;
  color: #888;
  font-size: 12px;
}

.action-buttons {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
}

.document-container {
  margin-bottom: 24px;
}

.document-content {
  padding: 16px;
  background-color: #f9f9f9;
  border: 1px solid #e8e8e8;
  border-radius: 4px;
  max-height: 500px;
  overflow-y: auto;
  white-space: pre-wrap;
  word-break: break-word;
}

.upload-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 48px 0;
  color: #888;
  background-color: #f9f9f9;
  border: 1px dashed #d9d9d9;
  border-radius: 4px;
}
</style>
