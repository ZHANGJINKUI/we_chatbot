<template>
  <!-- <div class="测试区域" style="background-color: antiquewhite">
    <div v-if="loading">Loading...</div>
    <div v-else>{{ chatContent }}</div>
  </div> -->
  <div class="chat-page">
    <div class="chat-header">
      <h2>{{ currentChat?.title || '新对话' }}</h2>
      <div style="display: flex; gap: 10px;">
        <a-button type="primary" @click="startNewChat">新对话</a-button>
        <a-button @click="forceRefresh">强制刷新</a-button>
      </div>
    </div>
    
    <!-- 调试信息 -->
    <div class="debug-info" style="background-color: #f5f5f5; padding: 10px; margin-bottom: 10px; border-radius: 4px;">
      <p><strong>调试信息:</strong></p>
      <p>当前聊天ID: {{ currentChatId || '无' }}</p>
      <p>消息数量: {{ currentChat?.messages?.length || 0 }}</p>
      <p>输入框内容: {{ inputMessage }}</p>
    </div>
    
    <div class="chat-container">
      <div class="chat-messages" ref="chatContainer">
        <div v-if="!currentChat?.messages || currentChat.messages.length === 0" class="empty-message">
          <div class="welcome-content">
            <h3>欢迎使用智能公文助手</h3>
            <p>您可以：</p>
            <ul>
              <li>直接提问公文写作相关问题</li>
              <li>上传Word文档进行公文纠错</li>
              <li>要求对已上传的文档进行润色</li>
            </ul>
          </div>
        </div>
        <div v-for="message in currentChat?.messages" :key="message.id" :class="['message', message.role]">
          <div class="avatar">
            <img :src="roleInfo[message.role]?.avatar || userLogo" :alt="roleInfo[message.role]?.name || '用户'" />
          </div>
          <div class="content">
            <div class="name">{{ roleInfo[message.role]?.name || '用户' }}</div>
            
            <!-- 文件上传消息 -->
            <div v-if="message.type === 'file-upload'" class="file-message">
              <div class="file-icon">
                <FileTextOutlined />
              </div>
              <div class="file-info">
                <div class="file-name">{{ message.filename }}</div>
                <div class="file-status">{{ message.status === 'complete' ? '已上传' : '上传中...' }}</div>
              </div>
            </div>
            
            <!-- 普通文本消息 -->
            <div v-else class="text">{{ message.content }}</div>
            
            <!-- 消息状态 -->
            <div v-if="message.status === 'loading'" class="loading">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
            </div>
            <div v-if="message.status === 'error'" class="error">出错了，请重试</div>
          </div>
        </div>
      </div>
      <div class="chat-input">
        <div class="input-container">
          <div class="upload-button" :class="{ 'uploading': isUploading }">
            <a-upload
              v-model:file-list="uploadFileList"
              :before-upload="handleFileUpload"
              :show-upload-list="false"
              :multiple="false"
              :max-count="1"
              accept=".doc,.docx"
            >
              <PaperClipOutlined class="upload-icon" :spin="isUploading" />
            </a-upload>
          </div>
          <a-textarea
            v-model:value="inputMessage"
            placeholder="请输入消息..."
            :auto-size="{ minRows: 1, maxRows: 4 }"
            @keydown.enter.prevent="sendMessage"
          />
        </div>
        <a-button type="primary" :loading="sending" @click="sendMessage">发送</a-button>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { ref, watch, useTemplateRef, computed, nextTick, onUnmounted, onMounted } from 'vue'
import { message } from 'ant-design-vue'
import { useChatStore } from '@/stores/chat'
import { useAuthStore } from '@/stores/auth'
import { useFileStore } from '@/stores/file'
// -- 对话UI组件 -------------------------------
import { Chat } from '@kousum/semi-ui-vue'
import type { Message } from '@/types/ChatType'
import type { UploadProps } from 'ant-design-vue'
import { PaperClipOutlined, FileTextOutlined } from '@ant-design/icons-vue'
// 替换openRouter服务
// @ts-ignore - Ignore missing type declaration for openRouter
// import openRouterService from '@/api/openRouter'
import weChatbotService from '@/services/weChatbotService'
// --    图标    ------------------------------
import systemLogo from '@/assets/system.png'
import assistantLogo from '@/assets/robot.png'
import userLogo from '@/assets/user-avatar.png'
// --------------------------------------------

defineOptions({
  name: 'ChatPage'
})
// --------------------------------------------
const chatStore = useChatStore()
const fileStore = useFileStore()
const currentChatId = computed(() => chatStore.currentChatId)
const currentChat = computed(() => chatStore.currentChat)
const inputMessage = ref('')
const sending = ref(false)
const chatContainer = ref<HTMLElement | null>(null)

// 生成UUID函数
const generateUUID = (): string => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// 监听当前chatID变化
watch(
  () => currentChatId.value,
  async newChatId => {
    if (newChatId) {
      try {
        // 根据chatID获取内容
        message.success('currentChatId:' + newChatId)
      } catch (error) {
        console.error('Failed to load chat:', error)
      }
    } else {
      message.info('No chat selected')
    }
  },
  { immediate: true }
) // 立即执行一次以处理初始状态
// --------------------------------------------
const authStore = useAuthStore()
const currentUser = computed(() => authStore.currentUser)
const username = computed(() => currentUser.value?.username)

// 定义角色信息
const roleInfo = {
  user: {
    name: username.value, // 使用当前登录用户名
    avatar: userLogo
  },
  assistant: {
    name: '小助手',
    avatar: assistantLogo
  },
  system: {
    name: '系统消息',
    avatar: systemLogo
  }
}
// --------------------------------------------
const chatRef = useTemplateRef('chatRef')
let chats = ref<Message[]>([])

// 添加documentContent存储当前的文档内容
const documentContent = ref<string | null>(null)
// 添加documentId存储当前的文档ID
const documentId = ref<string | null>(null)

chats.value = [
  {
    role: 'system',
    id: '0',
    createAt: new Date().getTime(),
    content: "Hello, I'm your AI assistant.",
    status: 'complete'
  }
]
// --------------------------------------------
// 发送消息，替换原有的发送消息方法
const sendMessage = async () => {
  if (!inputMessage.value.trim() || sending.value) return;
  
  const messageText = inputMessage.value.trim();
  inputMessage.value = '';
  sending.value = true;
  
  console.log('发送消息:', messageText);
  
  // 0. 确保currentChat存在，如果不存在则创建一个新对话
  if (!currentChat.value || !currentChat.value.id) {
    console.log('创建新对话');
    const newChat = chatStore.createNewChat();
    // 等待新对话创建完成
    await nextTick();
  }
  
  try {
    // 1. 创建用户消息
    const userMessage = {
      role: 'user',
      content: messageText,
      id: generateUUID(),
      status: 'complete',
      createAt: Date.now()
    };
    
    // 2. 创建助手消息占位
    const assistantMessage = {
      role: 'assistant',
      content: '',
      id: generateUUID(),
      status: 'loading',
      createAt: Date.now()
    };
    
    // 3. 直接更新消息数组 - 不依赖现有数组
    let messages = [];
    
    // 如果已有系统消息，则保留
    if (Array.isArray(currentChat.value.messages)) {
      const systemMsg = currentChat.value.messages.find(msg => msg.role === 'system');
      if (systemMsg) {
        messages.push(systemMsg);
      }
      
      // 保留之前所有消息
      currentChat.value.messages.forEach(msg => {
        if (msg.role !== 'system') {
          messages.push(msg);
        }
      });
    } else {
      // 添加默认系统消息
      messages.push({
        role: 'system',
        content: "我是小公，您的智能公文助手！",
        id: '0',
        createAt: Date.now(),
        status: 'complete'
      });
    }
    
    // 4. 添加用户消息和助手消息
    messages.push(userMessage);
    messages.push(assistantMessage);
    
    // 5. 更新聊天
    chatStore.updateCurrentChat({
      messages: messages
    });
    
    // 6. 滚动到底部
    await nextTick();
    scrollToBottom();
    
    // 7. 准备历史记录 - 不包含最新的助手消息
    const history = messages.slice(0, -1).map(msg => ({
      role: msg.role,
      content: msg.content
    }));
    
    // 8. 发送请求并处理响应
    await weChatbotService.sendChatRequest(
      messageText,
      history,
      (content) => {
        try {
          // 更新助手消息内容
          if (!Array.isArray(currentChat.value.messages)) {
            console.error('消息数组无效');
            return;
          }
          
          // 获取最后一条消息（应该是助手消息）
          const lastMessage = currentChat.value.messages[currentChat.value.messages.length - 1];
          
          if (lastMessage && lastMessage.role === 'assistant') {
            // 创建一个全新的消息数组
            const updatedMessages = [...currentChat.value.messages];
            updatedMessages[updatedMessages.length - 1] = {
              ...lastMessage,
              content: content
            };
            
            // 更新聊天
            chatStore.updateCurrentChat({
              messages: updatedMessages
            });
            
            // 滚动到底部
            nextTick(() => scrollToBottom());
          }
        } catch (error) {
          console.error('更新内容时出错:', error);
        }
      },
      () => {
        try {
          // 设置助手消息为完成状态
          if (!Array.isArray(currentChat.value.messages)) {
            console.error('消息数组无效');
            return;
          }
          
          // 获取最后一条消息
          const lastMessage = currentChat.value.messages[currentChat.value.messages.length - 1];
          
          if (lastMessage && lastMessage.role === 'assistant') {
            // 创建一个全新的消息数组
            const updatedMessages = [...currentChat.value.messages];
            updatedMessages[updatedMessages.length - 1] = {
              ...lastMessage,
              status: 'complete'
            };
            
            // 更新聊天
            chatStore.updateCurrentChat({
              messages: updatedMessages
            });
          }
          
          sending.value = false;
        } catch (error) {
          console.error('完成回调时出错:', error);
          sending.value = false;
        }
      },
      (error) => {
        try {
          console.error('发送消息出错:', error);
          
          // 设置助手消息为错误状态
          if (Array.isArray(currentChat.value.messages)) {
            const lastMessage = currentChat.value.messages[currentChat.value.messages.length - 1];
            
            if (lastMessage && lastMessage.role === 'assistant') {
              // 创建一个全新的消息数组
              const updatedMessages = [...currentChat.value.messages];
              updatedMessages[updatedMessages.length - 1] = {
                ...lastMessage,
                content: '出错了，请重试',
                status: 'error'
              };
              
              // 更新聊天
              chatStore.updateCurrentChat({
                messages: updatedMessages
              });
            }
          }
          
          sending.value = false;
        } catch (errorHandlingError) {
          console.error('处理错误时出错:', errorHandlingError);
          sending.value = false;
        }
      }
    );
  } catch (error) {
    console.error('发送消息失败:', error);
    sending.value = false;
  }
};
// --------------------------------------------
// 滚动到底部的函数
const scrollToBottom = () => {
  if (chatContainer.value) {
    setTimeout(() => {
      chatContainer.value!.scrollTop = chatContainer.value!.scrollHeight
    }, 0)
  }
}

// 确保消息变化时正确更新UI
watch(() => currentChat.value?.messages, (newMessages) => {
  console.log('消息列表变化，当前数量:', newMessages?.length);
  if (newMessages?.length > 0) {
    console.log('首条消息:', newMessages[0]);
    console.log('末条消息:', newMessages[newMessages.length - 1]);
  }
  nextTick(() => {
    scrollToBottom();
  });
}, { deep: true });

// 在组件挂载时初始化
onMounted(() => {
  console.log('ChatPage组件已挂载');
  if (currentChat.value?.messages?.length) {
    console.log('初始消息数量:', currentChat.value.messages.length);
  }
  nextTick(() => {
    scrollToBottom();
  });

  if (!chatStore.currentChat.id) {
    console.debug('创建新的对话')
    chatStore.createNewChat()
  }

  // 尝试连接后端
  weChatbotService.checkHealth()
    .then(isConnected => {
      console.debug('后端连接状态:', isConnected)
      if (isConnected) {
        message.success('已连接到后端服务')
      } else {
        message.error('无法连接到后端服务')
      }
    })
    .catch(error => {
      console.error('检查后端连接时出错:', error)
      message.error('检查后端连接时出错')
    })
})

// 开始新对话
const startNewChat = () => {
  console.debug('手动开始新对话')
  chatStore.createNewChat()
  inputMessage.value = ''
}

// 移除调试模式
const showDebug = ref(false) // 设置为false以隐藏调试信息

// 文件上传相关
const uploadFileList = ref<any[]>([])
const isUploading = ref(false)

// 处理文件上传
const handleFileUpload = async (file: File) => {
  if (!file) return false

  // 文件类型验证
  const validTypes = ['.doc', '.docx', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
  const isValidType = validTypes.some(type => {
    return file.type.includes(type) || file.name.endsWith(type)
  })

  if (!isValidType) {
    message.error('只支持Word文档(.doc/.docx)')
    return false
  }

  // 文件大小验证（限制为10MB）
  const isLt10M = file.size / 1024 / 1024 < 10
  if (!isLt10M) {
    message.error('文件大小不能超过10MB')
    return false
  }
  
  try {
    isUploading.value = true
    
    // 创建文件上传消息
    const fileUploadMessage = {
      role: 'user',
      type: 'file-upload',
      filename: file.name,
      id: generateUUID(),
      createAt: Date.now(),
      status: 'loading',
      content: `上传文件: ${file.name}`
    }
    
    // 添加消息到对话
    if (currentChat.value && currentChat.value.id) {
      const messages = Array.isArray(currentChat.value.messages) 
        ? [...currentChat.value.messages] 
        : []
      
      // 添加文件上传消息
      messages.push(fileUploadMessage)
      
      // 更新对话
      chatStore.updateCurrentChat({
        messages
      })
      
      // 滚动到底部
      nextTick(() => scrollToBottom())
    }
    
    // 使用file store的上传功能
    await fileStore.uploadFile(file)
    
    // 更新文件上传消息状态
    if (currentChat.value && currentChat.value.id) {
      const messages = [...currentChat.value.messages]
      const fileMessageIndex = messages.findIndex(msg => msg.id === fileUploadMessage.id)
      
      if (fileMessageIndex !== -1) {
        messages[fileMessageIndex] = {
          ...messages[fileMessageIndex],
          status: 'complete'
        }
      }
      
      // 添加系统回复消息
      messages.push({
        role: 'system',
        content: `文件"${file.name}"已上传成功，您可以要求我对该文档进行公文纠错或润色。`,
        id: generateUUID(),
        createAt: Date.now(),
        status: 'complete'
      })
      
      // 更新对话
      chatStore.updateCurrentChat({
        messages
      })
      
      // 滚动到底部
      nextTick(() => scrollToBottom())
    }
    
    message.success('文件上传成功')
    return false // 阻止默认上传行为
  } catch (error) {
    // 更新文件上传消息为错误状态
    if (currentChat.value && currentChat.value.id) {
      const messages = [...currentChat.value.messages]
      const fileMessageIndex = messages.findIndex(msg => 
        msg.id === fileUploadMessage?.id || (msg.type === 'file-upload' && msg.status === 'loading')
      )
      
      if (fileMessageIndex !== -1) {
        messages[fileMessageIndex] = {
          ...messages[fileMessageIndex],
          status: 'error'
        }
        
        // 更新对话
        chatStore.updateCurrentChat({
          messages
        })
      }
    }
    
    message.error('文件上传失败')
    console.error('文件上传错误:', error)
    return false
  } finally {
    isUploading.value = false
  }
}

// 强制刷新
const forceRefresh = () => {
  console.debug('强制刷新')
  chatStore.createNewChat()
  inputMessage.value = ''
}
</script>
<style lang="less" scoped>
.chat-page {
  height: 100%;
  display: flex;
  flex-direction: column;
  background-color: #f9fafb;
}

.chat-header {
  padding: 16px;
  border-bottom: 1px solid #eaeaea;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #fff;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
  
  h2 {
    font-size: 18px;
    color: #333;
    margin: 0;
  }
  
  .header-buttons {
    display: flex;
    gap: 8px;
  }
}

.chat-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}

.message {
  display: flex;
  margin-bottom: 18px;
  width: 100%; 
  align-items: flex-start;
}

.message .avatar {
  width: 40px;
  height: 40px;
  margin-right: 12px;
  flex-shrink: 0; /* 防止头像缩小 */
  border-radius: 50%;
  overflow: hidden;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.message .avatar img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
}

.message .content {
  flex: 1;
  max-width: calc(100% - 70px);
  background-color: #f5f5f5;
  padding: 12px 16px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
  transition: all 0.2s ease;
}

.message .name {
  font-weight: 600;
  margin-bottom: 5px;
  font-size: 13px;
  color: #5a5a5a;
}

.message .text {
  white-space: pre-wrap;
  word-break: break-word;
  color: #333;
  font-size: 14px;
  line-height: 1.6;
}

.message.user {
  flex-direction: row-reverse;
}

.message.user .avatar {
  margin-right: 0;
  margin-left: 12px;
}

.message.user .content {
  background-color: #e6f7ff;
  text-align: right;
  border-bottom-right-radius: 4px;
}

.message.assistant .content {
  background-color: #f0f9eb;
  border-bottom-left-radius: 4px;
}

.message.system .content {
  background-color: #f7f1fe;
  border: 1px dashed #d3adf7;
}

.chat-input {
  padding: 16px;
  border-top: 1px solid #eaeaea;
  display: flex;
  gap: 10px;
  background-color: #fff;
}

.input-container {
  position: relative;
  display: flex;
  flex: 1;
  border: 1px solid #d9d9d9;
  border-radius: 10px;
  background: #fff;
  padding: 10px 14px;
  align-items: center;
  transition: all 0.3s ease;
  
  &:hover, &:focus-within {
    border-color: #40a9ff;
    box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.15);
  }
}

.upload-button {
  display: flex;
  align-items: center;
  margin-right: 8px;
  cursor: pointer;
  
  &.uploading {
    .upload-icon {
      color: #1890ff;
    }
  }
}

.upload-icon {
  font-size: 20px;
  color: #595959;
  transition: color 0.3s;
  &:hover {
    color: #1890ff;
  }
}

.chat-input :deep(.ant-input) {
  border: none;
  box-shadow: none;
  padding: 0;
  resize: none;
  flex: 1;
  font-size: 14px;
  &:focus {
    box-shadow: none;
  }
}

// 调整a-button的样式
.chat-input .ant-btn {
  height: 42px;
  border-radius: 10px;
  font-weight: 500;
  padding: 0 16px;
}

.empty-message {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: #666;
  padding: 20px;
}

.welcome-content {
  max-width: 600px;
  text-align: center;
  background-color: #fff;
  padding: 32px;
  border-radius: 16px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  
  h3 {
    margin-bottom: 16px;
    color: #333;
    font-size: 20px;
  }
  
  ul {
    list-style-type: none;
    padding: 0;
    margin: 20px 0 0;
    text-align: left;
    
    li {
      margin: 12px 0;
      padding-left: 24px;
      position: relative;
      
      &:before {
        content: '•';
        position: absolute;
        left: 8px;
        color: #1890ff;
        font-size: 18px;
      }
    }
  }
}

.file-message {
  display: flex;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.03);
  border-radius: 8px;
  padding: 10px 12px;
  margin-bottom: 4px;
  
  .file-icon {
    font-size: 24px;
    margin-right: 12px;
    color: #1890ff;
  }
  
  .file-info {
    flex: 1;
    
    .file-name {
      font-weight: 500;
      margin-bottom: 3px;
    }
    
    .file-status {
      font-size: 12px;
      color: #888;
    }
  }
}

.loading {
  display: flex;
  justify-content: center;
  margin-top: 6px;
  
  .dot {
    width: 6px;
    height: 6px;
    background-color: #1890ff;
    border-radius: 50%;
    margin: 0 3px;
    display: inline-block;
    animation: dots 1.5s infinite ease-in-out;
    
    &:nth-child(2) {
      animation-delay: 0.5s;
    }
    
    &:nth-child(3) {
      animation-delay: 1s;
    }
  }
}

@keyframes dots {
  0%, 80%, 100% { 
    transform: scale(0);
    opacity: 0;
  }
  40% { 
    transform: scale(1);
    opacity: 1;
  }
}

.error {
  color: #ff4d4f;
  margin-top: 4px;
  font-size: 12px;
}
</style>
