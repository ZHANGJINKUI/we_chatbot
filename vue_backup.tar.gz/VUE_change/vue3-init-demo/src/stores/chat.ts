import { ref, onMounted, onUnmounted } from 'vue'
import { defineStore } from 'pinia'
import type { ChatListRequest, ChatItem, Message } from '@/types/ChatType'
import { fetchChatListApi, deleteChatApi } from '@/api/chat'
import axios from 'axios'
import { saveChatMessages } from '@/utils/http'

export const useChatStore = defineStore('chat', () => {
  // 状态
  const chatListData = ref<ChatItem[]>([])
  const currentChat = ref<ChatItem>({
    id: '',
    title: '',
    messages: [] as Message[]
  })
  const currentChatId = ref<string>('')
  const loading = ref(false)

  // 处理模拟API响应
  const handleMockResponse = (event: CustomEvent) => {
    const { chatId, response } = event.detail;
    console.log('收到模拟API响应:', chatId, response);
    
    if (response && response.data && response.data.messages) {
      // 找到聊天对象并更新
      const chat = chatListData.value.find(item => item.id === chatId);
      if (chat) {
        chat.messages = response.data.messages;
        
        // 如果是当前选中的聊天，也更新currentChat
        if (currentChatId.value === chatId) {
          currentChat.value = { ...chat };
        }
      }
      
      // 标记加载完成
      loading.value = false;
    }
  };

  // 设置事件监听器
  onMounted(() => {
    if (typeof window !== 'undefined') {
      window.addEventListener('mockChatMessagesResponse', handleMockResponse as EventListener);
    }
  });

  // 移除事件监听器
  onUnmounted(() => {
    if (typeof window !== 'undefined') {
      window.removeEventListener('mockChatMessagesResponse', handleMockResponse as EventListener);
    }
  });

  // 请求文件列表
  const fetchChatList = async (params: ChatListRequest) => {
    loading.value = true
    chatListData.value = []
    try {
      const data = await fetchChatListApi(params)
      if (data && data.length > 0) chatListData.value = data
    } catch (error) {
      console.error('fetchChatListApi失败:', error)
    } finally {
      loading.value = false
    }
  }

  // 获取特定对话的消息历史
  const fetchChatMessages = async (chatId: string) => {
    if (!chatId) return

    loading.value = true
    try {
      // 这里调用后端API获取对话消息
      // 注意：这个请求会被interceptor拦截并模拟响应
      await axios.get(`/api/chat/messages/${chatId}`)
      
      // 处理不在handleMockResponse中，因为它被拦截了
    } catch (error) {
      // 如果请求被拦截，这里不会执行
      console.error(`获取对话${chatId}的消息失败:`, error)
      loading.value = false
    }
  }

  // 设置当前文件
  const setCurrentChat = (chat: ChatItem) => {
    currentChat.value = chat
    currentChatId.value = chat.id
  }
  
  // 设置当前聊天ID
  const setCurrentChatId = async (chatId: string) => {
    // 如果与当前ID相同，不做操作
    if (currentChatId.value === chatId) return
    
    currentChatId.value = chatId
    console.log('切换到对话:', chatId)
    
    // 如果有匹配的聊天记录，设置currentChat
    const chat = chatListData.value.find(item => item.id === chatId)
    if (chat) {
      // 先设置基本信息
      currentChat.value = {...chat}
      
      // 如果没有消息或消息为空数组，尝试从服务器获取
      if (!chat.messages || chat.messages.length === 0) {
        console.log('从服务器获取历史消息')
        await fetchChatMessages(chatId)
      }
    }
  }

  // 创建新对话
  const createNewChat = () => {
    console.log('创建新对话')
    const newChat: ChatItem = {
      id: Date.now().toString(), // 使用时间戳作为临时ID
      title: '新对话',
      messages: [{
        role: 'system',
        id: '0',
        createAt: Date.now(),
        content: "我是小公，您的智能公文助手！",
        status: 'complete'
      }]
    }
    currentChat.value = newChat
    currentChatId.value = newChat.id
    // 将新对话添加到列表开头
    chatListData.value.unshift(newChat)
    console.log('新对话创建完成:', newChat)
    
    // 保存到localStorage
    if (newChat.id) {
      saveChatMessages(newChat.id, newChat.messages || []);
    }
    
    return newChat
  }

  // 更新当前对话
  const updateCurrentChat = (payload: ChatItem | Message[] | Partial<ChatItem>) => {
    if (!currentChat.value) {
      console.error('当前没有选中的对话');
      return;
    }
    
    // 如果传入的是数组，则认为是消息数组
    if (Array.isArray(payload)) {
      currentChat.value.messages = payload;
    } 
    // 如果传入的是对象且包含messages属性
    else if (typeof payload === 'object') {
      // 合并对象，保留现有属性
      currentChat.value = {
        ...currentChat.value,
        ...payload
      };
    }
    
    // 更新对话列表中的对应对话
    const index = chatListData.value.findIndex(item => item.id === currentChatId.value);
    if (index !== -1) {
      chatListData.value[index] = { ...currentChat.value };
      
      // 保存到localStorage
      if (currentChat.value.id && currentChat.value.messages) {
        saveChatMessages(currentChat.value.id, currentChat.value.messages);
      }
    }
  }

  // 删除文件
  const deleteChat = async (chatId: string) => {
    try {
      await deleteChatApi(chatId)
      // 如果删除的是当前选中的对象，清空选中状态
      if (currentChat.value.id === chatId) {
        currentChat.value = {
          id: '',
          title: '',
          messages: [] as Message[]
        }
        currentChatId.value = ''
      }
      
      // 从列表中移除
      const index = chatListData.value.findIndex(item => item.id === chatId)
      if (index !== -1) {
        chatListData.value.splice(index, 1)
      }
      
      // 从localStorage删除
      if (typeof window !== 'undefined') {
        localStorage.removeItem(`chat_messages_${chatId}`);
      }
    } catch (error) {
      console.error('Failed to delete chat:', error)
      throw error
    }
  }

  return {
    chatListData,
    currentChat,
    currentChatId,
    loading,
    fetchChatList,
    fetchChatMessages,
    setCurrentChat,
    setCurrentChatId,
    createNewChat,
    updateCurrentChat,
    deleteChat
  }
})
