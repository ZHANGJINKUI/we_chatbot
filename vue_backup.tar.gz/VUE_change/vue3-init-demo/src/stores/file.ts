import { ref } from 'vue'
import { defineStore } from 'pinia'
import type { UploadProps } from 'ant-design-vue'
import type { FileListRequest, FileItem, FileFormData } from '@/types/FileType'
import {
  fetchFileListApi,
  deleteFileApi,
  uploadFileApi,
  downloadFileApi,
  previewFileApi,
  previewModifiedFileApi,
  confirmModifyApi
} from '@/api/file'
import type { ChatItem } from '@/types/ChatType'

export interface FileDocument {
  id?: string
  name: string
  content: string
  size: number
  type: string
  uploadTime: Date
  processedContent?: string
}

export const useFileStore = defineStore('file', () => {
  const fileListData = ref<FileItem[]>([])
  const loadingFetchList = ref<boolean>(false)
  // 请求文件列表
  const fetchFileList = async (params: FileListRequest) => {
    try {
      loadingFetchList.value = true
      fileListData.value = [] // 清空数据
      const data = await fetchFileListApi(params)
      if (data && data.length > 0) fileListData.value = data
    } catch (error) {
      console.error('fetchFileListApi失败:', error)
    } finally {
      loadingFetchList.value = false
    }
  }
  // ---------------------------------------------
  const currentFile = ref<FileDocument | null>(null)
  
  // 历史文件列表
  const fileHistory = ref<FileDocument[]>([])
  
  // 设置当前文件
  function setCurrentFile(file: FileDocument) {
    currentFile.value = file
    
    // 将文件添加到历史记录
    if (!fileHistory.value.find(f => f.name === file.name && f.uploadTime === file.uploadTime)) {
      fileHistory.value.push(file)
      
      // 保存到localStorage
      saveFileHistory()
    }
  }
  
  // 清除当前文件
  function clearCurrentFile() {
    currentFile.value = null
  }
  
  // 更新处理后的文档内容
  function updateProcessedContent(content: string) {
    if (currentFile.value) {
      currentFile.value.processedContent = content
      
      // 更新历史记录中的对应文件
      const historyFile = fileHistory.value.find(
        f => f.name === currentFile.value?.name && 
        f.uploadTime === currentFile.value?.uploadTime
      )
      
      if (historyFile) {
        historyFile.processedContent = content
      }
      
      // 保存到localStorage
      saveFileHistory()
    }
  }
  
  // 保存文件历史到localStorage
  function saveFileHistory() {
    try {
      localStorage.setItem('fileHistory', JSON.stringify(fileHistory.value))
    } catch (error) {
      console.error('保存文件历史记录失败:', error)
    }
  }
  
  // 从localStorage加载文件历史
  function loadFileHistory() {
    try {
      const savedHistory = localStorage.getItem('fileHistory')
      if (savedHistory) {
        // 转换日期字符串回Date对象
        const parsed = JSON.parse(savedHistory)
        fileHistory.value = parsed.map((file: any) => ({
          ...file,
          uploadTime: new Date(file.uploadTime)
        }))
      }
    } catch (error) {
      console.error('加载文件历史记录失败:', error)
    }
  }
  
  // 初始化时加载历史数据
  loadFileHistory()
  // ---------------------------------------------
  // 删除文件
  const deleteFile = async (fileId: string) => {
    try {
      await deleteFileApi(fileId)
      // 如果删除的是当前选中的文件，清空选中状态
      if (currentFile.value?.id === fileId) {
        currentFile.value = null
      }
    } catch (error) {
      console.error('Failed to delete file:', error)
    }
  }
  // ------------------------------------------------------
  const loadingUpload = ref<boolean>(false)
  const uploadFileList = ref<UploadProps['fileList'] | undefined>([])
  // 文件上传
  const uploadFile: (params: FileFormData) => Promise<FileItem> = async (params: FileFormData) => {
    try {
      loadingUpload.value = true
      const formData = new FormData()
      formData.append('userid', params.userid)
      formData.append('file', params.file) // 单文件
      // params.file.forEach(f => { // 多文件
      //   formData.append('file', f)
      // })
      return await uploadFileApi(formData)
    } catch (err) {
      console.error('Failed to upload file:', err)
      throw err
    } finally {
      loadingUpload.value = false
    }
  }
  // ------------------------------------------------------
  const loadingDownload = ref<boolean>(false)
  // 文件下载
  const downloadFile = async (_id: string) => {
    try {
      loadingDownload.value = true
      const response = await downloadFileApi({ id: _id })
      const url = window.URL.createObjectURL(new Blob([response.data]))

      const filename = currentFile.value?.name || ''
      // 生成毫秒级时间戳
      const timestamp = new Date().getTime()
      // 分割文件名和扩展名
      const lastDotIndex = filename.lastIndexOf('.')
      const name = lastDotIndex !== -1 ? filename.substring(0, lastDotIndex) : filename
      const extension = lastDotIndex !== -1 ? filename.substring(lastDotIndex) : ''
      // 组合新文件名：原文件名_时间戳.扩展名
      const newFilename = `${name}_${timestamp}${extension}`

      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', newFilename) // 设置带时间戳的文件名
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (err) {
      console.error('Failed to download file:', err)
      throw err
    } finally {
      loadingDownload.value = false
    }
  }
  // ------------------------------------------------------
  // 文件预览
  const previewFile = async (_id: string) => {
    try {
      const response = await previewFileApi({ id: _id })
      return response.data // 返回blob数据
    } catch (err) {
      console.error('Failed to preview file:', err)
    }
  }

  // 修改文件预览
  const previewModifiedFile = async (file: FileItem, chat: ChatItem) => {
    try {
      const response = await previewModifiedFileApi({ file, chat })
      return response.data // 返回blob数据
    } catch (err) {
      console.error('Failed to preview modified file:', err)
    }
  }
  // ------------------------------------------------------
  // 文档修改状态
  const hasModifiedDoc = ref<boolean>(false)
  
  // 设置文档修改状态
  const setHasModifiedDoc = (status: boolean) => {
    hasModifiedDoc.value = status
  }
  // ------------------------------------------------------
  // 确认修改
  const confirmModify = async (file: FileItem, chat: ChatItem) => {
    try {
      await confirmModifyApi({ file, chat })
      // 重置状态
      hasModifiedDoc.value = false
    } catch (err) {
      console.error('Failed to confirm modify:', err)
    }
  }
  // ------------------------------------------------------
  return {
    fileListData,
    loadingFetchList,
    fetchFileList,
    currentFile,
    fileHistory,
    setCurrentFile,
    clearCurrentFile,
    updateProcessedContent,
    deleteFile,
    loadingUpload,
    uploadFile,
    uploadFileList,
    loadingDownload,
    downloadFile,
    previewFile,
    previewModifiedFile,
    hasModifiedDoc,
    setHasModifiedDoc,
    confirmModify
  }
})
