import axios from 'axios'
import { useFileStore } from '@/stores/file'

// 创建一个没有baseURL的axios实例，这样请求会通过Vite代理
const axiosInstance = axios.create({
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
});

interface ChatMessage {
  role: string;
  content: string;
}

/**
 * 检查消息是否与文档处理相关
 * @param message 用户消息
 * @returns boolean 是否与文档处理相关
 */
const isDocumentRelatedQuery = (message: string): boolean => {
  const docKeywords = [
    '文档', '公文', '纠错', '润色', '文件', 
    '上传', '处理', '修改', '校对', '检查',
    '改进', '修复', '纠正', '审核', '改良'
  ];
  
  return docKeywords.some(keyword => message.includes(keyword));
}

const weChatbotService = {
  // 格式化消息以符合API要求
  formatMessagesForAPI(messages: any[]): string {
    const formattedMessages = messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }))
    return JSON.stringify(formattedMessages)
  },

  // 新的聊天请求方法
  async sendChatRequest(
    message: string,
    chatHistory: ChatMessage[],
    onContent: (content: string) => void,
    onComplete: () => void,
    onError: (error: any) => void
  ): Promise<void> {
    try {
      console.log('开始发送消息:', message)
      
      // 检查消息是否与文档处理相关
      const isDocRequest = isDocumentRelatedQuery(message);
      const fileStore = useFileStore();
      const hasUploadedDoc = fileStore.currentFile && fileStore.currentFile.content;
      
      // 如果是文档处理请求并且有上传的文档，附加文档内容
      let docContent = null;
      if (isDocRequest && hasUploadedDoc && fileStore.currentFile) {
        docContent = fileStore.currentFile.content;
        console.log('检测到文档处理请求，附加文档内容，长度:', docContent?.length || 0);
      }
      
      // 构建URL和参数
      const url = '/api/stream-chat'
      const params = new URLSearchParams()
      params.append('message', message)
      params.append('chat_history', JSON.stringify(chatHistory))
      
      // 如果有文档内容，添加到参数
      if (docContent) {
        params.append('document_content', docContent);
      }
      
      console.log('请求参数:', params.toString())
      
      const response = await axiosInstance.get(`${url}?${params.toString()}`, {
        headers: {
          'Accept': 'text/event-stream'
        }
      })
      
      console.log('收到完整响应:', response.status)
      
      // 处理响应
      const text = response.data || ''
      
      // 拆分所有SSE消息
      const messages = text.split('\n\n')
      console.log(`接收到 ${messages.length} 个SSE消息`)
      
      // 收集到的完整内容
      let fullContent = ''
      
      try {
        // 处理每个消息
        for (const msg of messages) {
          if (!msg || !msg.trim()) continue
          
          if (msg.startsWith('data: ')) {
            const data = msg.substring(6).trim()
            
            if (data === 'end') {
              console.log('检测到结束标记')
              break
            }
            
            try {
              const parsedData = JSON.parse(data)
              console.log('解析的数据:', parsedData)
              
              if (parsedData && parsedData.content) {
                fullContent = parsedData.content // 完整替换内容而不是追加
                try {
                  onContent(fullContent)
                } catch (contentError) {
                  console.error('调用内容回调时出错:', contentError)
                }
              }
              
              // 如果响应包含处理后的文档内容，更新文件存储
              if (parsedData && parsedData.processed_document) {
                try {
                  console.log('收到处理后的文档内容，长度:', parsedData.processed_document.length);
                  fileStore.updateProcessedContent(parsedData.processed_document);
                } catch (docError) {
                  console.error('更新处理后的文档内容时出错:', docError);
                }
              }
            } catch (parseError) {
              console.error('解析消息失败:', parseError, data)
            }
          }
        }
      } catch (processError) {
        console.error('处理消息时出错:', processError)
      }
      
      console.log('完整内容:', fullContent)
      
      // 确保调用完成回调
      try {
        onComplete()
      } catch (completeError) {
        console.error('调用完成回调时出错:', completeError)
      }
    } catch (error) {
      console.error('聊天请求错误:', error)
      try {
        onError(error)
      } catch (errorCallbackError) {
        console.error('调用错误回调时出错:', errorCallbackError)
      }
    }
  },

  // 流式聊天响应
  async streamChatResponse(
    message: string,
    documentContent: string | null,
    chatHistory: string,
    onContent: (content: string) => void,
    onComplete: () => void
  ): Promise<string | null> {
    try {
      console.log('开始发送消息:', message)
      
      // 构建URL和参数
      const url = '/api/stream-chat'
      const params = new URLSearchParams()
      params.append('message', message)
      if (documentContent) {
        params.append('document_content', documentContent)
      }
      params.append('chat_history', chatHistory)
      
      console.log('请求参数:', params.toString())
      
      // 模拟流式响应效果，但使用普通Axios请求
      const fullResponse = await axiosInstance.get(`${url}?${params.toString()}`, {
        headers: {
          'Accept': 'text/event-stream'
        }
      })
      
      console.log('收到完整响应:', fullResponse.status)
      
      // 手动分段处理响应文本
      const text = fullResponse.data
      
      // 拆分所有SSE消息
      const messages = text.split('\n\n')
      console.log(`接收到 ${messages.length} 个SSE消息`)
      
      // 收集到的完整内容
      let fullContent = ''
      
      // 处理每个消息
      for (const msg of messages) {
        if (!msg.trim()) continue
        
        if (msg.startsWith('data: ')) {
          const data = msg.substring(6).trim()
          
          if (data === 'end') {
            console.log('检测到结束标记')
            break
          }
          
          try {
            const parsedData = JSON.parse(data)
            console.log('解析的数据:', parsedData)
            
            if (parsedData.content) {
              fullContent += parsedData.content
              // 直接更新
              onContent(parsedData.content)
            }
          } catch (error) {
            console.error('解析消息失败:', error, data)
          }
        }
      }
      
      console.log('完整内容:', fullContent)
      
      // 无论如何都确保调用完成回调
      onComplete()
      
      return null
    } catch (error) {
      console.error('聊天请求错误:', error)
      // 确保即使发生错误也调用完成回调
      onComplete()
      throw error
    }
  },

  // 健康检查
  async checkHealth() {
    try {
      console.log('正在检查后端连接...')
      const response = await axiosInstance.get('/api/health-check')
      console.log('健康检查成功:', response)
      return true
    } catch (error) {
      console.error('Server connection check failed:', error)
      return false
    }
  },
  
  // 下载处理后的文档
  async downloadProcessedDocument() {
    try {
      window.open('/api/download-result', '_blank');
      return true;
    } catch (error) {
      console.error('下载处理后的文档失败:', error);
      return false;
    }
  }
}

export default weChatbotService 