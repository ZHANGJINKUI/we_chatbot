<template>
  <div class="test-page">
    <h1>测试页面</h1>
    <p>如果你能看到这个页面，说明路由系统工作正常</p>
    
    <div class="test-content">
      <div class="test-box" style="background-color: #f9c2ff;">
        Box 1
      </div>
      <div class="test-box" style="background-color: #a8e6cf;">
        Box 2
      </div>
      <div class="test-box" style="background-color: #ffd3b6;">
        Box 3
      </div>
    </div>

    <div class="buttons">
      <button @click="goToHome">返回首页</button>
      <button @click="goToLogin">返回登录页</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'

const router = useRouter()

// 导航方法
const goToHome = () => {
  router.push('/auth/home')
}

const goToLogin = () => {
  router.push('/login')
}
</script>

<style scoped>
.test-page {
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
  font-family: Arial, sans-serif;
}

h1 {
  color: #333;
  text-align: center;
}

p {
  text-align: center;
  margin-bottom: 30px;
  font-size: 18px;
}

.test-content {
  display: flex;
  justify-content: space-between;
  margin-bottom: 30px;
}

.test-box {
  width: 30%;
  height: 150px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #333;
  font-weight: bold;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.buttons {
  display: flex;
  justify-content: center;
  gap: 20px;
}

button {
  padding: 10px 20px;
  background-color: #4caf50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
}

button:hover {
  background-color: #45a049;
}
</style> 