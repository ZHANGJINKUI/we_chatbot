<template>
  <div class="direct-test-page">
    <h1>直接测试页面（无BasicLayout）</h1>
    <p>如果你能看到这个页面，说明路由和Vue渲染工作正常，但绕过了BasicLayout</p>
    
    <div class="color-blocks">
      <div class="color-block" style="background-color: #FF5733;">区块1</div>
      <div class="color-block" style="background-color: #33FF57;">区块2</div>
      <div class="color-block" style="background-color: #3357FF;">区块3</div>
      <div class="color-block" style="background-color: #F3FF33;">区块4</div>
    </div>

    <div class="nav-buttons">
      <button @click="goToTest">测试页(带布局)</button>
      <button @click="goToHome">首页</button>
      <button @click="goToLogin">登录页</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'

const router = useRouter()

const goToTest = () => {
  router.push('/auth/test')
}

const goToHome = () => {
  router.push('/auth/home')
}

const goToLogin = () => {
  router.push('/login')
}
</script>

<style scoped>
.direct-test-page {
  padding: 30px;
  max-width: 800px;
  margin: 0 auto;
  background-color: #f5f5f5;
  border-radius: 10px;
  box-shadow: 0 0 20px rgba(0,0,0,0.1);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

h1 {
  color: #444;
  text-align: center;
  margin-top: 0;
}

p {
  text-align: center;
  margin-bottom: 30px;
  color: #666;
}

.color-blocks {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
  margin-bottom: 40px;
  flex-grow: 1;
}

.color-block {
  height: 150px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: bold;
  font-size: 24px;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.15);
}

.nav-buttons {
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-top: auto;
}

button {
  padding: 12px 24px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.2s;
}

button:hover {
  background-color: #0056b3;
}
</style> 