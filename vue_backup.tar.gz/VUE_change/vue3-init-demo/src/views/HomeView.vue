<template>
    <div style="padding: 20px; background-color: #f0f0f0; min-height: 500px;">
        <h2 style="color: #333; text-align: center;">简化版首页</h2>
        
        <!-- 聊天区域 - 直接内联显示不使用复杂组件 -->
        <div style="margin-top: 20px; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h3>聊天区域</h3>
            <div style="min-height: 200px; border: 1px solid #eee; padding: 10px; margin: 10px 0;">
                <p>这里应该显示聊天消息</p>
            </div>
            <div style="display: flex;">
                <input type="text" placeholder="输入消息..." 
                       style="flex: 1; padding: 8px; border: 1px solid #ddd; border-radius: 4px; margin-right: 10px;" />
                <button style="padding: 8px 16px; background: #1890ff; color: white; border: none; border-radius: 4px;">
                    发送
                </button>
            </div>
        </div>
        
        <!-- 文件区域 -->
        <div style="margin-top: 20px; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h3>文件区域</h3>
            <div style="min-height: 100px; border: 1px solid #eee; padding: 10px;">
                <p>这里应该显示文件列表</p>
            </div>
            <button style="margin-top: 10px; padding: 8px 16px; background: #52c41a; color: white; border: none; border-radius: 4px;">
                上传文件
            </button>
        </div>
    </div>
</template>

<script setup>
// 简化版本无需复杂逻辑
</script>
