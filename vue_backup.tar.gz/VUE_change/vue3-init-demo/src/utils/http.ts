/** 封装axios **/
import axios from 'axios'
import type { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios'
import { message, Modal } from 'ant-design-vue'
import { getToken } from './auth'
import { useAuthStore } from '@/stores/auth'
import { createVNode } from 'vue'
import { ExclamationCircleOutlined } from '@ant-design/icons-vue'

// axios配置
const config = {
  // baseURL: '/server-address/', // 发布地址
  baseURL: import.meta.env.VITE_BASE_URL, // api地址
  //   withCredentials: true, // 确保发送 cookies
  timeout: 30000 // 增加超时时间到30秒
}

// 定义返回值类型
export interface Result<T = any> {
  code: number
  msg: string
  data: T
}

// axios封装
class Http {
  // 定义一个axios的实例
  private instance: AxiosInstance

  // 构造函数：初始化
  constructor(config: AxiosRequestConfig) {
    // 创建axios实例
    this.instance = axios.create(config)
    // 配置拦截器
    this.interceptors()
  }

  // 拦截器：处理请求发送和请求返回的数据
  private interceptors() {
    // 请求发送之前的处理
    this.instance.interceptors.request.use(
      config => {
        console.log(`==== 发送请求到 ${config.baseURL || ''}${config.url} ====`)
        console.log('请求方法:', config.method)
        console.log('请求数据:', config.data ? config.data : config.params)
        console.log('完整请求配置:', config)

        // 设置Content-Type
        if (config.url && ['/file/upload'].includes(config.url)) {
          config.headers!['Content-Type'] = 'multipart/form-data'
        } else config.headers!['Content-Type'] = 'application/json'

        // -- 临时修改请求地址 --------------------------------------------------------
        // if(config.url && ['/file/upload','/file/download','/file/preview'].includes(config.url)) {
        //   config.baseURL = import.meta.env.VITE_BASE_URL_DEV
        // }
        // ---------------------------------------------------------------------------

        /** 在请求头部添加token **/
        let token = getToken() // 从cookies/sessionStorage里获取
        if (token) {
          // 添加token到头部
          config.headers!['Authorization'] = token
        }

        // 如果后端没有实现，这里添加模拟API的拦截器
        if (config.url && config.url.startsWith('/api/chat/messages/')) {
          // 暂时返回一个假响应，直到后端API实现
          console.log('模拟获取对话消息API:', config.url);
          
          // 取消原始请求
          const controller = new AbortController();
          config.signal = controller.signal;
          controller.abort();
          
          // 在浏览器端保存一些假消息
          if (typeof window !== 'undefined') {
            // 获取chatId
            const chatId = config.url.split('/').pop();
            
            // 从localStorage获取或初始化消息存储
            let chatMessages;
            try {
              const savedMessages = localStorage.getItem(`chat_messages_${chatId}`);
              chatMessages = savedMessages ? JSON.parse(savedMessages) : null;
            } catch (e) {
              console.error('解析本地存储的消息失败:', e);
              chatMessages = null;
            }
            
            // 如果没有找到保存的消息，就创建一个默认消息
            if (!chatMessages) {
              chatMessages = {
                messages: [
                  {
                    role: 'system',
                    id: '0',
                    createAt: Date.now(),
                    content: '这是一个历史对话。您可以继续聊天。',
                    status: 'complete'
                  }
                ]
              };
              
              // 保存到localStorage
              localStorage.setItem(`chat_messages_${chatId}`, JSON.stringify(chatMessages));
            }
            
            // 模拟一个返回对象
            setTimeout(() => {
              // 这里不能直接修改config，因为请求已被取消
              // 替代方案是通知状态管理器
              const mockResponse = { data: chatMessages };
              const event = new CustomEvent('mockChatMessagesResponse', { 
                detail: { chatId, response: mockResponse }
              });
              window.dispatchEvent(event);
            }, 200);
          }
        }
        return config
      },
      error => {
        error.data = {}
        error.data.msg = '服务器异常，请联系管理员！'
        return error
      }
    )

    // 请求返回数据的处理
    this.instance.interceptors.response.use(
      (response: AxiosResponse) => {
        // 处理blob响应
        if (response.config.responseType === 'blob') {
          return response
        }
        
        // 处理普通JSON响应
        const { data } = response
        // 数据不解密
        const res = data
        console.log(res) // res: { code: 200, data: null, msg: '请求成功' }

        if (res.code === 200) {
          return res.data
        } else if (res.code === 204) {
          // token过期 |无效
          Modal.warning({
            title: '提示',
            icon: createVNode(ExclamationCircleOutlined),
            content: '当前用户登录已超时，请重新登录！',
            onOk() {
              // console.log('ok')
              const authStore = useAuthStore()
              authStore.logout() // 执行退出
            }
          })
        } else {
          message.error(res.msg || '服务器出错！')
          return Promise.reject(new Error(res.msg || '服务器出错！'))
        }
      },
      error => {
        console.log('进入错误')
        error.data = {}
        if (error && error.response) {
          switch (error.response.status) {
            case 400:
              error.data.msg = '错误请求'
              break
            case 500:
              error.data.msg = '服务器内部错误'
              break
            case 404:
              error.data.msg = '请求未找到'
              break
            default:
              error.data.msg = `连接错误${error.response.status}`
              break
          }
          message.error(error.data.msg || '服务器连接出错！')
        } else {
          error.data.msg = '连接到服务器失败！'
          message.error(error.data.msg)
        }
        return Promise.reject(error)
      }
    )
  }

  /** RestFul api封装 **/
  // Get请求：注意这里params被解构了，后端获取参数的时候直接取字段名
  get<T = Result>(url: string, params?: object, config?: AxiosRequestConfig): Promise<T> {
    return this.instance.get(url, { params, ...config })
  }
  // Post请求
  post<T = Result>(url: string, data?: object, config?: AxiosRequestConfig): Promise<T> {
    return this.instance.post(url, data, config)
  }

  // Put请求
  put<T = Result>(url: string, data?: object): Promise<T> {
    return this.instance.put(url, data)
  }

  // DELETE请求
  delete<T = Result>(url: string): Promise<T> {
    return this.instance.delete(url)
  }
}

// 在聊天消息更新后保存到localStorage
export const saveChatMessages = (chatId: string, messages: any[]) => {
  if (typeof window !== 'undefined' && chatId) {
    try {
      localStorage.setItem(`chat_messages_${chatId}`, JSON.stringify({ messages }));
    } catch (e) {
      console.error('保存聊天消息到本地存储失败:', e);
    }
  }
};

export default new Http(config)
